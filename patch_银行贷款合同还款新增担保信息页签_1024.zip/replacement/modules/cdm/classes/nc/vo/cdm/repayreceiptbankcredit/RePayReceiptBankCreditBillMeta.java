package nc.vo.cdm.repayreceiptbankcredit;

import nc.vo.pubapp.pattern.model.meta.entity.bill.AbstractBillMeta;

public class RePayReceiptBankCreditBillMeta extends AbstractBillMeta {

	public RePayReceiptBankCreditBillMeta() {
		this.setParent(RePayReceiptBankCreditVO.class);
		this.addChildren(RePayReceiptBankCreditBVO.class);
		this.addChildren(RePayRcptBankInfo.class);
	}
}
