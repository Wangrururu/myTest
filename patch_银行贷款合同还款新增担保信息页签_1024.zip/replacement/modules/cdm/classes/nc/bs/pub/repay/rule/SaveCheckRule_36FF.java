package nc.bs.pub.repay.rule;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import nc.bs.framework.common.NCLocator;
import nc.impl.pubapp.pattern.rule.IRule;
import nc.itf.pub.contract.IContractQueryService;
import nc.itf.pub.repay.IRepayReceiptQueryService;
import nc.itf.tmpub.datemanage.DateManageProxy;
import nc.pubitf.pub.payreceipt.IPayReceiptQueryService;
import nc.vo.cdm.repayreceiptbankcredit.RePayRcptBankInfo;
import nc.vo.cdm.repayreceiptbankcredit.RePayReceiptBankCreditBVO;
import nc.vo.cdm.repayreceiptbankcredit.RePayReceiptBankCreditVO;
import nc.vo.pub.BusinessException;
import nc.vo.pub.SuperVO;
import nc.vo.pub.VOStatus;
import nc.vo.pub.constant.CDMBusConstant;
import nc.vo.pub.contract.AdjustRateMethodEnum;
import nc.vo.pub.contract.ContractVO;
import nc.vo.pub.lang.UFBoolean;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.payreceipt.AggPayReceiptVO;
import nc.vo.pub.payreceipt.PayReceiptVO;
import nc.vo.pub.repay.RepayReceiptBVO;
import nc.vo.pub.repay.RepayReceiptVO;
import nc.vo.pubapp.pattern.exception.ExceptionUtils;
import nc.vo.pubapp.pattern.model.entity.bill.IBill;
import nc.vo.tmpub.datemanage.DateManageQueryVO;
import nc.vo.tmpub.initdate.CheckInitDateVO;
import nc.vo.tmpub.initdate.CheckedInitDateHelper;

@SuppressWarnings("rawtypes")
public class SaveCheckRule_36FF implements IRule {

	@Override
	public void process(Object[] vos) {
		if (vos == null)
			return;
		IBill[] bills = (IBill[]) vos;
		for (IBill bill : bills) {
			//wry_1024_���������ͷŲ��ɴ��ڻ�������
			checkSaveInfo(bill);
			checkRePayIsNull(bill);
			checkInitDate(bill);
			existSameRepayDate(bill);
			repayofmntandintCheck(bill);
			checkPayPlan(bill);
			checkPayAmount(bill);
			checkRePayDate(bill);
			setAcceptDate(bill);
//			setRepayDate(bill);
			checkRepayMAI(bill);
			updateVersionNo(bill);
			foreignRepayCheck(bill);
			
		}
	}
	
	private void checkSaveInfo(IBill bill){
		RePayReceiptBankCreditVO parent = (RePayReceiptBankCreditVO) bill.getParent();
		RePayRcptBankInfo[] InfoChildrens = (RePayRcptBankInfo[]) bill.getChildren(RePayRcptBankInfo.class);
		RePayReceiptBankCreditBVO[] creditChildren = (RePayReceiptBankCreditBVO[]) bill.getChildren(RePayReceiptBankCreditBVO.class);
		UFDouble repayamount = (UFDouble) parent.getAttributeValue("repayamount");
		Double sum = 0.00D;
		//У������ͷŽ��ܴ���ռ�ý��,��ȡ�ܽ��ܴ��ڱ�ͷ�������У��
		for(int i=0;i<InfoChildrens.length;i++){
			RePayRcptBankInfo InfoChildren = InfoChildrens[i];
			String def2 = (String) InfoChildren.getAttributeValue("def2");
			UFDouble guaranteeamount = (UFDouble)InfoChildren.getAttributeValue("guaranteeamount");
			int row = i+1;
			if(null==guaranteeamount){
				ExceptionUtils
				.wrappBusinessException("������Ϣ��:"+row+"��ռ�ý���Ϊ��");
			}
			if(null==def2 && null!=repayamount){
				ExceptionUtils
				.wrappBusinessException("������Ϣ��:"+row+"���ͷŽ�����ռ�ý�����Ϊ��");
			}
			if(null != def2 && Double.parseDouble(def2)>guaranteeamount.getDouble()){
				ExceptionUtils
				.wrappBusinessException("������Ϣ��:"+row+"���ͷŽ��ɴ���ռ�ý��");
			}
			sum+=Double.parseDouble(def2);
		}
		if(null!=repayamount && repayamount.getDouble()<sum){
			ExceptionUtils
			.wrappBusinessException("�ͷ��ܽ�"+sum +"���ܴ��ڻ�����"+repayamount);
		}
	}
	private void foreignRepayCheck(IBill bill){
		SuperVO parent = (SuperVO) bill.getParent();
		UFBoolean isForeign = (UFBoolean) parent.getAttributeValue(RepayReceiptVO.ISFOREIGN);
		if(isForeign!=null&&UFBoolean.TRUE.equals(isForeign)){
			String foreignCurr = (String) parent.getAttributeValue(RepayReceiptVO.PK_FOREIGNCURR);
			UFDouble foreignRate = (UFDouble) parent.getAttributeValue(RepayReceiptVO.FOREIGNRATE);
			UFDouble foreignAmount = (UFDouble) parent.getAttributeValue(RepayReceiptVO.FOREIGNAMOUNT);
			if(foreignCurr==null||"".equals(foreignCurr)){
				ExceptionUtils
				.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
						.getNCLangRes().getStrByID("3615pub_0",
								"03615pub-0766")/*
												 * @res
												 * "��㻹��ʱ����㻹����ֲ���Ϊ��"
												 */);
			}
			if(foreignRate==null||UFDouble.ZERO_DBL.compareTo(foreignRate)>=0){
				ExceptionUtils
				.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
						.getNCLangRes().getStrByID("3615pub_0",
								"03615pub-0767")/*
												 * @res
												 * "��㻹��ʱ�������ʲ���Ϊ��"
												 */);
			}
			if(foreignAmount==null||UFDouble.ZERO_DBL.compareTo(foreignAmount)>=0){
				ExceptionUtils
				.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
						.getNCLangRes().getStrByID("3615pub_0",
								"03615pub-0768")/*
												 * @res
												 * "��㻹��ʱ��������Ϊ��"
												 */);
			}
		}
	}

	private void existSameRepayDate(IBill bill) {
		SuperVO parent = (SuperVO) bill.getParent();
		UFDate repaydate = (UFDate) parent
				.getAttributeValue(RepayReceiptVO.REPAYDATE);
		String pk_contract = (String) parent
				.getAttributeValue(RepayReceiptVO.PK_CONTRACT);
		String billtype = (String) parent
				.getAttributeValue(RepayReceiptVO.PK_BILLTYPECODE);
		String vbillno = (String) parent
				.getAttributeValue(RepayReceiptVO.VBILLNO);
		UFDouble repayamount = (UFDouble) parent
				.getAttributeValue(RepayReceiptVO.REPAYAMOUNT);
		if (repayamount == null || UFDouble.ZERO_DBL.equals(repayamount))
			return;
		try {
			boolean isExist = NCLocator.getInstance()
					.lookup(IRepayReceiptQueryService.class)
					.isExistRePay(pk_contract, repaydate, billtype, vbillno);
			if (isExist) {
				ExceptionUtils
						.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
								.getNCLangRes().getStrByID("3615pub_0",
										"03615pub-0739")/*
														 * @res
														 * "�ú�ͬ���Ѵ�����ͬ�������ڵĻ��,����"
														 */);
			}
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
	}

	/**
	 * �ڳ�У��
	 * 
	 * @param bill
	 */
	private void checkInitDate(IBill bill) {
		try {
			SuperVO parent = (SuperVO) bill.getParent();
			UFDate repaydate = (UFDate) parent
					.getAttributeValue(RepayReceiptVO.REPAYDATE);
			String billtype = (String) parent
					.getAttributeValue(RepayReceiptVO.PK_BILLTYPECODE);
			String pk_org = (String) parent
					.getAttributeValue(RepayReceiptVO.PK_ORG);
			UFBoolean isinitial = (UFBoolean) parent
					.getAttributeValue(RepayReceiptVO.ISINITIAL);

			CheckInitDateVO checkInitDateVO = new CheckInitDateVO();
			checkInitDateVO.setCheckedDate(RepayReceiptVO.REPAYDATE);
			checkInitDateVO
					.setCheckedDateName(nc.vo.ml.NCLangRes4VoTransl
							.getNCLangRes().getStrByID("3615pub_0",
									"03615pub-0489")/* @res "��������" */);
			checkInitDateVO.setCheckedDateValue(repaydate);
			if (billtype.startsWith("36F")) {
				checkInitDateVO
						.setModuleName(nc.vo.ml.NCLangRes4VoTransl
								.getNCLangRes().getStrByID("3615pub_0",
										"03615pub-0490")/* @res "���д������" */);
				checkInitDateVO.setModuleCode("3615");
			} else if (billtype.startsWith("36M")) {
				checkInitDateVO
						.setModuleName(nc.vo.ml.NCLangRes4VoTransl
								.getNCLangRes().getStrByID("3615pub_0",
										"03615pub-0491")/* @res "�ڲ��������" */);
				checkInitDateVO.setModuleCode("3635");
			}
			checkInitDateVO.setPk_org(pk_org);
			if (isinitial == null) {
				isinitial = UFBoolean.FALSE;
			}
			checkInitDateVO.setIsInit(isinitial);
			String errorInfo = CheckedInitDateHelper
					.checkInitDate(checkInitDateVO);
			if (errorInfo != null) {
				throw new BusinessException(errorInfo);
			}
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
	}

	/**
	 * ����Ϣʱ�������汾��
	 * 
	 * @param bill
	 */
	private void checkRepayMAI(IBill bill) {
		UFDouble interest = (UFDouble) bill.getParent().getAttributeValue(
				RepayReceiptVO.INTEREST);
		String pk_contract = (String) bill.getParent().getAttributeValue(RepayReceiptVO.PK_CONTRACT);
		UFBoolean repayMAI = (UFBoolean) bill.getParent().getAttributeValue(
				RepayReceiptVO.REPAYOFMNTANDINT);
		UFBoolean isInterest = isInterest(pk_contract);
		UFBoolean specialRate = isSpecialRate(pk_contract);
		if((isInterest==null||UFBoolean.FALSE.equals(isInterest))&& repayMAI != null && UFBoolean.TRUE.equals(repayMAI)){
			ExceptionUtils
			.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
					.getNCLangRes().getStrByID("3615pub_0",
							"03615pub-0774")/* @res "��������Ϣʱ�����������汾��ҵ��" */);
		}
		if((UFBoolean.TRUE.equals(specialRate))&& repayMAI != null && UFBoolean.TRUE.equals(repayMAI)){
			ExceptionUtils
			.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
					.getNCLangRes().getStrByID("3615pub_0",
							"03615pub-0776")/* @res "������ʽΪ��������ʱ�����������汾��ҵ��" */);
		}
		if (interest != null && !UFDouble.ZERO_DBL.equals(interest)
				&& repayMAI != null && UFBoolean.TRUE.equals(repayMAI)) {
			ExceptionUtils
					.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
							.getNCLangRes().getStrByID("3615pub_0",
									"03615pub-0727")/* @res "����Ϣʱ�����������汾��ҵ��" */);

		}
	}

	/**
	 * ȥ���������ں��ʱ��
	 * 
	 * @param bill
	 */
//	private void setRepayDate(IBill bill) {
//		UFDate repaydate = (UFDate) bill.getParent().getAttributeValue(
//				RepayReceiptVO.REPAYDATE);
//		bill.getParent().setAttributeValue(RepayReceiptVO.REPAYDATE,
//				repaydate.asBegin());
//	}

	/**
	 * ��֤������͸���Ϣ����ͬʱΪ��
	 * 
	 * @param bill
	 */
	private void checkRePayIsNull(IBill bill) {
		SuperVO parent = (SuperVO) bill.getParent();
		UFDouble interest = (UFDouble) parent
				.getAttributeValue(RepayReceiptVO.INTEREST);
		if (interest == null) {
			boolean b = false;// ����û������
			SuperVO[] childrenVOss = (SuperVO[]) bill
					.getChildren(RePayReceiptBankCreditBVO.class);
			SuperVO[] childrenVOs = (SuperVO[]) bill
					.getChildren(RePayReceiptBankCreditBVO.class);
			if (childrenVOs != null) {
				for (SuperVO superVO : childrenVOs) {
					int status = superVO.getStatus();
					if (status == VOStatus.NEW || status == VOStatus.UNCHANGED
							|| status == VOStatus.UPDATED) {
						b = true;// ����������
					}
				}
			}
			if (!b) {
				ExceptionUtils
						.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
								.getNCLangRes().getStrByID("3615pub_0",
										"03615pub-0295")/* @res "������ͻ���Ϣ����ͬʱΪ�ա�" */);
			}
		}
	}

	/**
	 * ͬһ�������ڳ���ͬһ����ƻ��Ķ�����¼
	 * 
	 * @param bill
	 */
	private void checkPayPlan(IBill bill) {
		SuperVO[] childrenVOs = (SuperVO[]) bill
				.getChildren(RePayReceiptBankCreditBVO.class);
		if (childrenVOs == null)
			return;
		Set<String> planSet = new HashSet<String>();
		for (SuperVO childrenVO : childrenVOs) {
			if (childrenVO.getStatus() != VOStatus.DELETED) {
				String pk_repayplan = (String) childrenVO
						.getAttributeValue(RepayReceiptBVO.PK_REPAYPLAN);
				if (planSet.contains(pk_repayplan)) {
					ExceptionUtils
							.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
									.getNCLangRes().getStrByID("3615pub_0",
											"03615pub-0296")/*
															 * @res
															 * "ͬһ�������ڳ���ͬһ����ƻ��Ķ�����¼����ϲ���"
															 */);
				} else {
					planSet.add(pk_repayplan);
				}
			}
		}
	}

	/**
	 * ��֤�������Ƿ����δ��������
	 * 
	 * @param bill
	 */
	private void checkPayAmount(IBill bill) {
		// SuperVO parentVO = (SuperVO) bill.getParent();
		SuperVO[] childrenVOs = (SuperVO[]) bill
				.getChildren(RePayReceiptBankCreditBVO.class);
		HashMap<String, UFDouble> map = new HashMap<String, UFDouble>();
		if (childrenVOs == null)
			return;
		for (SuperVO childrenVO : childrenVOs) {
			if (childrenVO.getStatus() == VOStatus.DELETED)
				continue;
			String pk_repayplan = (String) childrenVO
					.getAttributeValue(RepayReceiptBVO.PK_REPAYPLAN);
			UFDouble repayAmount = map.get(pk_repayplan);
			if (repayAmount == null) {
				map.put(pk_repayplan, (UFDouble) childrenVO
						.getAttributeValue(RepayReceiptBVO.REPAYAMOUNT));
			} else {
				map.remove(pk_repayplan);
				map.put(pk_repayplan, repayAmount.add((UFDouble) childrenVO
						.getAttributeValue(RepayReceiptBVO.REPAYAMOUNT)));
			}
			UFDouble apRepayAmount = (UFDouble) childrenVO
					.getAttributeValue(RepayReceiptBVO.APREPAYAMOUNT);
			if (apRepayAmount.compareTo(map.get(pk_repayplan)) < 0) {
				ExceptionUtils
						.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
								.getNCLangRes().getStrByID("3615pub_0",
										"03615pub-0297")/*
														 * @res
														 * "�����Ӧ�ô���δ��������"
														 */);
			}
		}
	}

	/**
	 * ��֤�������ڲ������ڷſ�����
	 * 
	 * @param bill
	 */
	private void checkRePayDate(IBill bill) {
		SuperVO parentVO = (SuperVO) bill.getParent();
		SuperVO[] childrenVOs = (SuperVO[]) bill
				.getChildren(RePayReceiptBankCreditBVO.class);
		if (childrenVOs == null)
			return;
		UFDate repayDate = (UFDate) parentVO
				.getAttributeValue(RepayReceiptVO.REPAYDATE);
		List<String> payrcptList = new ArrayList<String>();
		for (SuperVO childrenVO : childrenVOs) {
			if (childrenVO.getStatus() != VOStatus.DELETED) {
				String pk_payrcpt = (String) childrenVO
						.getAttributeValue(RepayReceiptBVO.PK_PAYRCPT);
				payrcptList.add(pk_payrcpt);
			}
		}
		String[] payrcpts = payrcptList.toArray(new String[payrcptList.size()]);
		AggPayReceiptVO[] aggPayReceiptVOs = getPayRcpts(payrcpts);
		if(aggPayReceiptVOs==null||aggPayReceiptVOs.length==0){
			return;
		}
		List<String> errPays = new ArrayList<String>();
		for (AggPayReceiptVO aggPayReceiptVO : aggPayReceiptVOs) {
			PayReceiptVO payReceiptVO = aggPayReceiptVO.getParentVO();
			UFDate payDate = payReceiptVO.getPaydate();
			if (repayDate.before(payDate)) {
				errPays.add(payReceiptVO.getVbillno());
			}
		}
		if (errPays.size() > 0) {
			StringBuffer sb = new StringBuffer();
			for (String errPay : errPays) {
				sb.append("[" + errPay + "]");
			}
			ExceptionUtils.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
					.getNCLangRes().getStrByID("3615pub_0", "03615pub-0298")/*
																			 * @res
																			 * "�������ڲ����ڷſ�����֮ǰ;�ſ�ţ�"
																			 */
					+ sb.toString());
		}
	}

	private AggPayReceiptVO[] getPayRcpts(String[] pks) {
		IPayReceiptQueryService queryService = NCLocator.getInstance().lookup(
				IPayReceiptQueryService.class);
		String[] newpks = removeRepeat(pks);
		if(newpks==null||newpks.length==0){
			return null;
		}
		AggPayReceiptVO[] aggs = null;
		try {
			aggs = queryService.queryBillByPks(newpks);
		} catch (BusinessException e) {
			ExceptionUtils
					.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
							.getNCLangRes().getStrByID("3615pub_0",
									"03615pub-0299")/* @res "��ѯ�ſ�����ʧ��" */);
		}
		return aggs;
	}

	private String[] removeRepeat(String[] strs) {
		if (strs == null || strs.length == 0) {
			return null;
		}
		Set<String> set = new HashSet<String>();
		for (String str : strs) {
			if (!set.contains(str)) {
				set.add(str);
			}
		}
		return set.toArray(new String[set.size()]);
	}

	/**
	 * ���汾�廹����岻��Ϊ��
	 * 
	 * @param bill
	 */
	private void repayofmntandintCheck(IBill bill) {
		RepayReceiptVO head = (RepayReceiptVO) bill.getParent();
		RepayReceiptBVO[] childrens = (RepayReceiptBVO[]) bill
				.getChildren(RePayReceiptBankCreditBVO.class);
		UFBoolean repayofmntandint = head.getRepayofmntandint();
		boolean b = true;
		if (childrens != null && childrens.length > 0) {
			for (RepayReceiptBVO repayReceiptBVO : childrens) {
				if (repayReceiptBVO.getStatus() != VOStatus.DELETED) {
					b = false;
				}
			}
		}
		if (b && repayofmntandint != null
				&& UFBoolean.TRUE.equals(repayofmntandint)) {
			ExceptionUtils
					.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
							.getNCLangRes().getStrByID("3615pub_0",
									"03615pub-0581")/* @res "���汾�廹����岻��Ϊ��" */);
		}
	}

	/**
	 * �����������ڣ��ڲ������ͬ���
	 * 
	 * @param bill
	 */
	private void setAcceptDate(IBill bill) {
		String billtype = (String) bill.getParent().getAttributeValue(
				RepayReceiptVO.PK_BILLTYPECODE);
		// �ڳ����ݲ�������������
		UFBoolean isinitial = (UFBoolean)bill.getParent().getAttributeValue(RepayReceiptVO.ISINITIAL);
		if (!CDMBusConstant.BILLTYPE_INNERREPAY.equals(billtype) || (isinitial != null && isinitial.booleanValue()))
			return;
		DateManageQueryVO queryVO = new DateManageQueryVO();
		UFDate repaydate = (UFDate) bill.getParent().getAttributeValue(
				RepayReceiptVO.REPAYDATE);
		String pk_group = (String) bill.getParent().getAttributeValue(
				RepayReceiptVO.PK_GROUP);
		String pk_org = (String) bill.getParent().getAttributeValue(
				RepayReceiptVO.PK_ORG);

		queryVO.setCurrentBusiDate(repaydate);
		queryVO.setMaxBillDate(repaydate);
		queryVO.setPk_group(pk_group);
		queryVO.setPk_org(pk_org);
		UFDate acceptDate = null;
		try {
			acceptDate = DateManageProxy.getDateManageService()
					.getProcessedBusiDate(queryVO);
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
		bill.getParent().setAttributeValue(RepayReceiptVO.ACCEPTDATE,
				acceptDate);
	}

	private void updateVersionNo(IBill bill) {
		RepayReceiptBVO[] childrens = (RepayReceiptBVO[]) bill
				.getChildren(RePayReceiptBankCreditBVO.class);
		if (childrens != null && childrens.length > 0) {
			for (RepayReceiptBVO repayReceiptBVO : childrens) {
				if (repayReceiptBVO.getStatus() != VOStatus.DELETED&&repayReceiptBVO.getPayversionno()==null) {
					repayReceiptBVO.setPayversionno(getVersionNoByPayPK(repayReceiptBVO.getPk_payrcpt()));
				}
			}
		}
	}

	/**
	 * ���ݷſ������ѯ�汾��
	 * 
	 * @param pk_payrcpt
	 * @return
	 */
	private Integer getVersionNoByPayPK(String pk_payrcpt) {
		try {
			AggPayReceiptVO[] aggvos = NCLocator.getInstance()
					.lookup(IPayReceiptQueryService.class)
					.queryBillByPks(new String[] { pk_payrcpt });
			if (aggvos == null || aggvos.length == 0) {
				return 1;
			}
			return aggvos[0].getParentVO().getVersionno();
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
		return null;
	}
	
	private UFBoolean isInterest(String pk_contract){
		IContractQueryService queryService = NCLocator.getInstance().lookup(
				IContractQueryService.class);
		UFBoolean isinterest = UFBoolean.TRUE;
		try {
			ContractVO contractvo = queryService.queryContractMainByPk(pk_contract);
			isinterest = contractvo.getIsinterest();
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
		return isinterest;
	}
	
	private UFBoolean isSpecialRate(String pk_contract){
		IContractQueryService queryService = NCLocator.getInstance().lookup(
				IContractQueryService.class);
		String adjratemethod = null;
		try {
			ContractVO contractvo = queryService.queryContractMainByPk(pk_contract);
			adjratemethod = contractvo.getAdjratemethod();
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
		if(adjratemethod!=null&&AdjustRateMethodEnum.SPECIALRATE.toStringValue().equals(adjratemethod)){
			return UFBoolean.TRUE;
		}
		return UFBoolean.FALSE;
	}
}