package nc.bs.pub.repay.rule;

import nc.bs.framework.common.NCLocator;
import nc.bs.pub.util.LockUtil;
import nc.impl.pubapp.pattern.rule.IRule;
import nc.itf.pub.contract.IContractManageService;
import nc.itf.pub.contract.IContractQueryService;
import nc.pubitf.pub.payreceipt.IPayReceiptQueryService;
import nc.vo.cdm.repayreceiptbankcredit.RePayReceiptBankCreditBVO;
import nc.vo.pub.BusinessException;
import nc.vo.pub.SuperVO;
import nc.vo.pub.contract.ContractExecTypeEnum;
import nc.vo.pub.contract.ContractExecVO;
import nc.vo.pub.contract.ContractVO;
import nc.vo.pub.lang.UFBoolean;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.payreceipt.PayReceiptSubVO;
import nc.vo.pub.pf.BillStatusEnum;
import nc.vo.pub.repay.RepayReceiptBVO;
import nc.vo.pub.repay.RepayReceiptVO;
import nc.vo.pubapp.pattern.exception.ExceptionUtils;
import nc.vo.pubapp.pattern.model.entity.bill.IBill;

@SuppressWarnings("rawtypes")
public class InsertContractExecRule_36FF implements IRule {

	@Override
	public void process(Object[] vos) {
		IBill[] bills = (IBill[]) vos;
		// �Ժ�ͬ����
		LockUtil.LockContract(bills, RepayReceiptVO.PK_CONTRACT);
		for (IBill bill : bills) {
			SuperVO superVO = (SuperVO) bill.getParent();
			String pk_contract = (String) superVO
					.getAttributeValue(RepayReceiptVO.PK_CONTRACT);
			int vbillstatus = (Integer) superVO
					.getAttributeValue(RepayReceiptVO.VBILLSTATUS);
			if (vbillstatus == BillStatusEnum.APPROVED.toIntValue()) {
				ContractExecVO intexec = getIntContractExecVO(superVO);
				ContractExecVO mntexec = getMntContractExecVO(bill);
				if (intexec != null)
					insertContractExecVO(intexec, pk_contract);
				if (mntexec != null)
					insertContractExecVO(mntexec, pk_contract);
			}
		}

	}

	private ContractExecVO getIntContractExecVO(SuperVO superVO) {
		ContractExecVO exec = getPubContractExecVO(superVO);
		String pk_contract = (String) superVO
				.getAttributeValue(RepayReceiptVO.PK_CONTRACT);
		UFDouble payinterest = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.INTEREST);// ����Ϣ���
		UFDate repaydate = (UFDate) superVO
				.getAttributeValue(RepayReceiptVO.REPAYDATE);
		if (payinterest == null || payinterest.compareTo(new UFDouble(0)) == 0)
			return null;
		UFDouble olcpayinterest = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.OLCINTEREST);// ����Ϣ��֯���ҽ��
		UFDouble glcpayinterest = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.GLCINTEREST);// ����Ϣ���ű��ҽ��
		UFDouble gllcpayinterest = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.GLLCINTEREST);// ����Ϣȫ�ֱ��ҽ��
		UFBoolean isinitial = (UFBoolean) superVO
				.getAttributeValue(RepayReceiptVO.ISINITIAL);
		UFDouble leftinterest = UFDouble.ZERO_DBL;
		UFBoolean isinterest = getIsinterest(pk_contract);
		if (UFBoolean.TRUE.equals(isinterest)) {
			leftinterest = getLeftInterest(pk_contract, repaydate);// δ����Ϣ���
			if (leftinterest != null) {
				leftinterest = leftinterest.sub(payinterest);
			}
			if (leftinterest.compareTo(new UFDouble(0)) < 0) {
				ExceptionUtils.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
						.getNCLangRes().getStrByID("3615pub_0","03615pub-0580")/*
														 * @res
														 * "����Ϣ���ܴ��ں�ͬ��δ����Ϣ��"
														 */);
			}
		}
		String summary = ContractExecTypeEnum.FLX.toStringValue();
		exec.setSummary(summary);
		exec.setPayinterest(payinterest);
		exec.setOlcpayinterest(olcpayinterest);
		exec.setGlcpayinterest(glcpayinterest);
		exec.setGllcpayinterest(gllcpayinterest);
		exec.setLeftinterest(leftinterest);
		exec.setInitialflag(isinitial);
		return exec;
	}

	private ContractExecVO getMntContractExecVO(IBill bill) {
		SuperVO superVO = (SuperVO) bill.getParent();
		ContractExecVO exec = getPubContractExecVO(superVO);
		String pk_contract = (String) superVO
				.getAttributeValue(RepayReceiptVO.PK_CONTRACT);
		UFDouble repayamount = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.REPAYAMOUNT);// ��������
		if (repayamount == null || repayamount.compareTo(new UFDouble(0)) == 0)
			return null;
		RepayReceiptBVO[] bodyvos = (RepayReceiptBVO[]) bill.getChildren(RePayReceiptBankCreditBVO.class);
		checkRePayAmount(bodyvos);
		UFDouble olcrepayamount = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.OLCREPAYAMOUNT);
		UFDouble glcrepayamount = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.GLCREPAYAMOUNT);
		UFDouble gllcrepayamount = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.GLLCREPAYAMOUNT);
		UFDouble leftrepayamount = getLeftAmount(pk_contract).sub(repayamount);// δ��������
		UFBoolean isinitial = (UFBoolean) superVO.getAttributeValue(RepayReceiptVO.ISINITIAL);
		if (leftrepayamount.compareTo(new UFDouble(0.0)) < 0) {
			ExceptionUtils
					.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
							.getNCLangRes().getStrByID("3615pub_0",
									"03615pub-0294")/* @res "���������δ������" */);
		}
		String summary = ContractExecTypeEnum.HBJ.toStringValue();
		exec.setSummary(summary);
		exec.setRepayamount(repayamount);
		exec.setOlcrepayamount(olcrepayamount);
		exec.setGlcrepayamount(glcrepayamount);
		exec.setGllcrepayamount(gllcrepayamount);
		exec.setLeftrepayamount(leftrepayamount);
		exec.setInitialflag(isinitial);
		return exec;
	}
	
	private void checkRePayAmount(RepayReceiptBVO[] bodyvos){
		StringBuffer repaycode = new StringBuffer();
		for (RepayReceiptBVO bodyvo : bodyvos) {
			String pk_repayplan = bodyvo.getPk_repayplan();
			UFDouble repayamount = bodyvo.getRepayamount();
			PayReceiptSubVO subvo = getPayReceiptSubVO(pk_repayplan);
			UFDouble unamount = subvo.getUnamount();
			if(unamount==null){
				unamount = UFDouble.ZERO_DBL;
			}
			if(unamount.compareTo(repayamount)<0){
				repaycode.append("["+subvo.getRepaycode()+"]");
			}
		}
		if(repaycode!=null&&!"".equals(repaycode.toString().trim())){
			ExceptionUtils.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
					.getNCLangRes().getStrByID("3615pub_0",
					"03615pub-0728")/* @res "���»���ƻ��Ļ��������δ������" */+repaycode.toString().trim());
		}
	}
	
	private PayReceiptSubVO getPayReceiptSubVO(String pk_repayplan){
		try {
			PayReceiptSubVO subvo = NCLocator.getInstance().lookup(IPayReceiptQueryService.class).queryPayReceiptSubVOByPrimaryKey(pk_repayplan);
			return subvo;
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
		return null;
	}

	private ContractExecVO getPubContractExecVO(SuperVO superVO) {
		ContractExecVO exec = new ContractExecVO();
		String pk_billtypecode = (String) superVO
				.getAttributeValue(RepayReceiptVO.PK_BILLTYPECODE);
		String vbillno = (String) superVO
				.getAttributeValue(RepayReceiptVO.VBILLNO);
		UFDate repayDate = (UFDate) superVO
				.getAttributeValue(RepayReceiptVO.REPAYDATE);
		String operator = (String) superVO
				.getAttributeValue(RepayReceiptVO.APPROVER);
		UFDouble olcrate = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.OLCRATE);
		UFDouble glcrate = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.GLCRATE);
		UFDouble gllcrate = (UFDouble) superVO
				.getAttributeValue(RepayReceiptVO.GLLCRATE);

		exec.setPk_billtypecode(pk_billtypecode);
		exec.setVbillno(vbillno);
		exec.setBusidate(repayDate);
		exec.setOperator(operator);
		exec.setOlcrate(olcrate);
		exec.setGlcrate(glcrate);
		exec.setGllcrate(gllcrate);

		return exec;
	}

	private void insertContractExecVO(ContractExecVO exec, String pk_contract) {
		IContractManageService conService = NCLocator.getInstance().lookup(
				IContractManageService.class);
		try {
			conService.insertContractExec(exec, pk_contract);
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
	}

	private UFDouble getLeftAmount(String pk_contract) {
		IContractQueryService queryService = NCLocator.getInstance().lookup(
				IContractQueryService.class);
		UFDouble leftAmount = new UFDouble();
		try {
			leftAmount = queryService.queryLeftAmount(pk_contract);
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
		return leftAmount;
	}

	private UFDouble getLeftInterest(String pk_contract,UFDate repaydate) {
		IContractQueryService queryService = NCLocator.getInstance().lookup(
				IContractQueryService.class);
		UFDouble leftInterest = new UFDouble();
		try {
			leftInterest = queryService.queryLeftInterest(pk_contract,repaydate);
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
		return leftInterest;
	}
	
	private UFBoolean getIsinterest(String pk_contract){
		IContractQueryService queryService = NCLocator.getInstance().lookup(
				IContractQueryService.class);
		UFBoolean isinterest = UFBoolean.TRUE;
		try {
			ContractVO contractvo = queryService.queryContractMainByPk(pk_contract);
			isinterest = contractvo.getIsinterest();
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
		return isinterest;
	}

}