package nc.bs.pub.action;

import nc.bs.pubapp.pf.action.AbstractPfAction;
import nc.bs.pub.repay.rule.SaveCheckRule_36FF;
import nc.bs.cdm.repayreceiptbankcredit.ace.bp.AceRePayReceiptBankCreditInsertBP;
import nc.bs.cdm.repayreceiptbankcredit.ace.bp.AceRePayReceiptBankCreditUpdateBP;
import nc.bs.cdm.repayreceiptbankcredit.plugin.bpplugin.RePayReceiptBankCreditPluginPoint;
import nc.impl.pubapp.pattern.rule.IRule;
import nc.impl.pubapp.pattern.rule.processer.CompareAroundProcesser;
import nc.vo.jcom.lang.StringUtil;
import nc.vo.cdm.repayreceiptbankcredit.AggRePayReceiptBankCreditVO;

public class N_36FF_SAVEBASE extends
		AbstractPfAction<AggRePayReceiptBankCreditVO> {

	@Override
	protected CompareAroundProcesser<AggRePayReceiptBankCreditVO> getCompareAroundProcesserWithRules(
			Object userObj) {
		CompareAroundProcesser<AggRePayReceiptBankCreditVO> processor = null;
		AggRePayReceiptBankCreditVO[] clientFullVOs = (AggRePayReceiptBankCreditVO[]) this
				.getVos();
		/*
		 * BillTransferTool<AggRePayReceiptBankCreditVO> tool = new
		 * BillTransferTool<AggRePayReceiptBankCreditVO>( clientFullVOs);
		 * clientFullVOs = tool.getClientFullInfoBill();
		 */
		if (!StringUtil.isEmptyWithTrim(clientFullVOs[0].getParentVO()
				.getPrimaryKey())) {
			processor = new CompareAroundProcesser<AggRePayReceiptBankCreditVO>(
					RePayReceiptBankCreditPluginPoint.UPDATE);
		} else {
			processor = new CompareAroundProcesser<AggRePayReceiptBankCreditVO>(
					RePayReceiptBankCreditPluginPoint.INSERT);
			
		}
		IRule<AggRePayReceiptBankCreditVO> checkRule = new SaveCheckRule_36FF();
		processor.addBeforeRule(checkRule);
		return processor;
	}

	@Override
	protected AggRePayReceiptBankCreditVO[] processBP(Object userObj,
			AggRePayReceiptBankCreditVO[] clientFullVOs,
			AggRePayReceiptBankCreditVO[] originBills) {
		AggRePayReceiptBankCreditVO[] bills = null;
		if (!StringUtil.isEmptyWithTrim(clientFullVOs[0].getParentVO()
				.getPrimaryKey())) {
			/*
			 * BillTransferTool<AggRePayReceiptBankCreditVO> transTool = new
			 * BillTransferTool<AggRePayReceiptBankCreditVO>( clientFullVOs);
			 * AggRePayReceiptBankCreditVO[] fullBills =
			 * transTool.getClientFullInfoBill(); AggRePayReceiptBankCreditVO[]
			 * originBills = transTool.getOriginBills(); bills = new
			 * AceRePayReceiptBankCreditUpdateBP
			 * ().update(fullBills,originBills);
			 */
			bills = new AceRePayReceiptBankCreditUpdateBP().update(
					clientFullVOs, originBills);
		} else {
			bills = new AceRePayReceiptBankCreditInsertBP()
					.insert(clientFullVOs);
		}
		return bills;
	}
}
