package nc.bs.pub.repay.rule;

import nc.bs.dao.BaseDAO;
import nc.bs.framework.common.NCLocator;
import nc.impl.pubapp.pattern.rule.IRule;
import nc.itf.pub.ia.IInterestAccrualService;
import nc.itf.pub.repay.IRepayReceiptQueryService;
import nc.pubitf.uapbd.CurrencyRateUtil;
import nc.vo.cdm.repayreceiptbankcredit.RePayReceiptBankCreditBVO;
import nc.vo.pub.BusinessException;
import nc.vo.pub.VOStatus;
import nc.vo.pub.constant.CDMBusConstant;
import nc.vo.pub.lang.UFBoolean;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.pf.BillStatusEnum;
import nc.vo.pub.repay.AggRepayReceiptVO;
import nc.vo.pub.repay.RepayReceiptBVO;
import nc.vo.pub.repay.RepayReceiptVO;
import nc.vo.pubapp.pattern.exception.ExceptionUtils;
import nc.vo.pubapp.pattern.model.entity.bill.IBill;

@SuppressWarnings("rawtypes")
public class CancelRePayOfAmountAndInterestRule_36FF implements IRule {

	@Override
	public void process(Object[] vos) {
		IBill[] bills = (IBill[]) vos;
		for (IBill bill : bills) {
			RepayReceiptVO parent = (RepayReceiptVO) bill.getParent();
			RepayReceiptBVO[] chilrens = (RepayReceiptBVO[]) bill
					.getChildren(RePayReceiptBankCreditBVO.class);
			if (parent.getRepayofmntandint() != null
					&& parent.getRepayofmntandint().equals(UFBoolean.TRUE)
					&& parent.getVbillstatus().equals(
							BillStatusEnum.APPROVED.toIntValue())) {
				AggRepayReceiptVO aggvo = new AggRepayReceiptVO();
				aggvo.setParent(parent);
				aggvo.setChildrenVO(chilrens);
				try {
					getInterestAccrualService()
							.cancelCalculateIntByRepay(aggvo);
					updateInterest(bill);
				} catch (BusinessException e) {
					ExceptionUtils.wrappException(e);
				}
			}
		}
	}

	private void updateInterest(IBill bill) throws BusinessException {
		RepayReceiptVO parent = (RepayReceiptVO) bill.getParent();
		
		parent.setInterest(null);
		parent.setOlcinterest(null);
		parent.setGlcinterest(null);
		parent.setGllcinterest(null);
		parent.setApinterest(null);
		parent.setOlcapinterest(null);
		parent.setGlcapinterest(null);
		parent.setGllcapinterest(null);
		parent.setSumamount(parent.getRepayamount());
		parent.setOlcsumamount(parent.getOlcrepayamount());
		parent.setGlcsumamount(parent.getGlcrepayamount());
		parent.setGllcsumamount(parent.getGllcrepayamount());
		parent.setStatus(VOStatus.UPDATED);
		setTaxNull(parent);
		updateForeignAmount(parent);
		parent.setDr(0);
		BaseDAO dao = new BaseDAO();
		dao.updateVO(parent);
		AggRepayReceiptVO[] aggvos = NCLocator.getInstance().lookup(IRepayReceiptQueryService.class).queryBillByPks(new String[]{parent.getPk_repayrcpt()});
		parent.setTs(aggvos[0].getParentVO().getTs());;
	}
	
	private void updateForeignAmount(RepayReceiptVO parent) throws BusinessException{
		if (!CDMBusConstant.BILLTYPE_REPAYRCPTBANKCREDIT.equals(parent
				.getPk_billtypecode())||(parent.getIsforeign()==null||UFBoolean.FALSE.equals(parent.getIsforeign())))
			return;
		String pk_foreigncurr = parent.getPk_foreigncurr();
		String pk_currtype = parent.getPk_currtype();
		UFDouble sumAmount = parent.getSumamount();
		UFDouble foreignRate = parent.getForeignrate();
		UFDate repayDate = parent.getRepaydate();
		String pk_org = parent.getPk_org();
		CurrencyRateUtil currRateUtil = CurrencyRateUtil
			.getInstanceByOrg(pk_org);
		UFDouble foreignAmount = currRateUtil.getAmountByOpp(pk_currtype,
				pk_foreigncurr, sumAmount, foreignRate, repayDate);
		parent.setForeignamount(foreignAmount);
	}
	
	private void setTaxNull(RepayReceiptVO parent){
		parent.setBusinesstax(null);
		parent.setUrbanconstrtax(null);
		parent.setEduaddtax(null);
		parent.setRivermanagefee(null);
		parent.setInterestaftfee(null);
		parent.setOlcinterestaftfee(null);
		parent.setGlcinterestaftfee(null);
		parent.setGllcinterestaftfee(null);
	}

	private IInterestAccrualService getInterestAccrualService() {
		return NCLocator.getInstance().lookup(IInterestAccrualService.class);
	}
}
