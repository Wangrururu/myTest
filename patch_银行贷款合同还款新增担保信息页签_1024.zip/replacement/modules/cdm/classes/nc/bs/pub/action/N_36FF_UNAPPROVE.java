package nc.bs.pub.action;

import nc.bs.pub.repay.rule.CancelRePayOfAmountAndInterestRule_36FF;
import nc.bs.pub.repay.rule.ContractStatusCheckRule;
import nc.bs.pub.repay.rule.DeleteContractExecRule;
import nc.bs.pub.repay.rule.UnApproveUpdateUnAmountRule_36FF;
import nc.bs.pub.rule.CDMSendDAPDELRule;
import nc.bs.pub.rule.CDMSetUnVoucherFieldRule;
import nc.bs.pubapp.pf.action.AbstractPfAction;
import nc.bs.cdm.repayreceiptbankcredit.ace.bp.AceRePayReceiptBankCreditUnApproveBP;
import nc.bs.cdm.repayreceiptbankcredit.plugin.bpplugin.RePayReceiptBankCreditPluginPoint;
import nc.bs.cdm.repayreceiptbankcredit.rule.RePayRcptBankUnBookkeptRule;
import nc.bs.pubapp.pub.rule.UnapproveStatusCheckRule;
import nc.impl.pubapp.pattern.rule.processer.CompareAroundProcesser;
import nc.vo.cdm.repayreceiptbankcredit.AggRePayReceiptBankCreditVO;
import nc.vo.cdm.tbb.TbbCommonUtil;
import nc.impl.pubapp.pattern.rule.IRule;
import nc.vo.pub.BusinessException;
import nc.vo.pub.VOStatus;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.pf.BillStatusEnum;
import nc.vo.trade.pub.IBillStatus;

public class N_36FF_UNAPPROVE extends
		AbstractPfAction<AggRePayReceiptBankCreditVO> {

	public N_36FF_UNAPPROVE() {
		super();
	}

	@Override
	protected CompareAroundProcesser<AggRePayReceiptBankCreditVO> getCompareAroundProcesserWithRules(
			Object userObj) {
		CompareAroundProcesser<AggRePayReceiptBankCreditVO> processor = new CompareAroundProcesser<AggRePayReceiptBankCreditVO>(
				RePayReceiptBankCreditPluginPoint.UNAPPROVE);
		IRule<AggRePayReceiptBankCreditVO> rule = new UnapproveStatusCheckRule();
		IRule<AggRePayReceiptBankCreditVO> unApproveUpdateUnAmountRule = new UnApproveUpdateUnAmountRule_36FF();
		IRule<AggRePayReceiptBankCreditVO> deleteContractExecRule = new DeleteContractExecRule();
		IRule<AggRePayReceiptBankCreditVO> unBookkeptRule = new RePayRcptBankUnBookkeptRule();
		IRule<AggRePayReceiptBankCreditVO> cdmSendDAPDELRule = new CDMSendDAPDELRule();
		IRule<AggRePayReceiptBankCreditVO> cdmSetUnVoucherFieldRule = new CDMSetUnVoucherFieldRule();
		IRule<AggRePayReceiptBankCreditVO> cancelRepayOfAAIRule = new CancelRePayOfAmountAndInterestRule_36FF();
		IRule<AggRePayReceiptBankCreditVO> contractStatusCheckRule = new ContractStatusCheckRule();

		processor.addBeforeRule(rule);
		processor.addBeforeRule(contractStatusCheckRule);
		processor.addBeforeRule(unBookkeptRule);
		processor.addBeforeRule(cdmSetUnVoucherFieldRule);
		processor.addBeforeRule(cancelRepayOfAAIRule);
		processor.addBeforeRule(unApproveUpdateUnAmountRule);
		processor.addBeforeRule(deleteContractExecRule);
		processor.addAfterRule(cdmSendDAPDELRule);
		return processor;
	}

	@Override
	protected AggRePayReceiptBankCreditVO[] processBP(Object userObj,
			AggRePayReceiptBankCreditVO[] clientFullVOs,
			AggRePayReceiptBankCreditVO[] originBills) {
		String tbbmessage = null;
		if (clientFullVOs != null && clientFullVOs.length > 0) {
			for (int i = 0; i < clientFullVOs.length; i++) {
				clientFullVOs[i].getParentVO().setStatus(VOStatus.UPDATED);
				if (clientFullVOs[i].getParentVO().getVbillstatus() != IBillStatus.CHECKPASS
						&& originBills[i].getParentVO().getVbillstatus() == IBillStatus.CHECKPASS) {
					try {
						tbbmessage = TbbCommonUtil.controlNtb(clientFullVOs[i],
								true, new UFDate());
						clientFullVOs[i].getParentVO().setInteractfield(
								tbbmessage);
					} catch (BusinessException e) {
						throw new RuntimeException(e.getMessage(), e);
					}
				}

				// clientFullVOs[i].getParentVO().setAttributeValue("vbillstatus",
				// BillStatusEnum.APPROVING.value());
			}
			AggRePayReceiptBankCreditVO[] bills = new AceRePayReceiptBankCreditUnApproveBP()
					.unApprove(clientFullVOs, originBills);
			return bills;
		}
		return null;
	}

}
