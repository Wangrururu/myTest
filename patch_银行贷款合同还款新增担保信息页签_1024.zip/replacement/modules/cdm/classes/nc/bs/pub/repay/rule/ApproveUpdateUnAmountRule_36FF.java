package nc.bs.pub.repay.rule;

import java.util.HashMap;

import nc.bs.framework.common.NCLocator;
import nc.impl.pubapp.pattern.rule.IRule;
import nc.pubitf.pub.payreceipt.IPayReceiptManagerService;
import nc.vo.cdm.repayreceiptbankcredit.RePayReceiptBankCreditBVO;
import nc.vo.pub.BusinessException;
import nc.vo.pub.SuperVO;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.pf.BillStatusEnum;
import nc.vo.pub.repay.RepayReceiptBVO;
import nc.vo.pub.repay.RepayReceiptVO;
import nc.vo.pubapp.pattern.exception.ExceptionUtils;
import nc.vo.pubapp.pattern.model.entity.bill.IBill;

@SuppressWarnings("rawtypes")
public class ApproveUpdateUnAmountRule_36FF implements IRule {

	@Override
	public void process(Object[] vos) {
		IBill[] bills = (IBill[]) vos;
		HashMap<String, UFDouble> primaryKeyToUnAmount = new HashMap<String, UFDouble>();
		for (IBill bill : bills) {
			SuperVO parent = (SuperVO) bill.getParent();
			Integer vbillstatus = (Integer) parent.getAttributeValue(RepayReceiptVO.VBILLSTATUS);
			if(BillStatusEnum.APPROVED.toIntValue()!=vbillstatus){
				continue;
			}
			SuperVO[] superVOs = (SuperVO[]) bill
					.getChildren(RePayReceiptBankCreditBVO.class);
			if (superVOs == null || superVOs.length < 1)
				continue;
			for (SuperVO superVO : superVOs) {
				String pk_repayplan = (String) superVO
						.getAttributeValue(RepayReceiptBVO.PK_REPAYPLAN);
				UFDouble payamount = (UFDouble) superVO
						.getAttributeValue(RepayReceiptBVO.REPAYAMOUNT);
				primaryKeyToUnAmount.put(pk_repayplan, payamount);
			}
		}
		if (primaryKeyToUnAmount.isEmpty())
			return;
		this.updateUnAmount(primaryKeyToUnAmount);
	}

	private void updateUnAmount(HashMap<String, UFDouble> primaryKeyToUnAmount) {
		IPayReceiptManagerService managerService = NCLocator.getInstance()
				.lookup(IPayReceiptManagerService.class);
		try {
			managerService.approveUpdateUnAmount(primaryKeyToUnAmount);
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
	}
}