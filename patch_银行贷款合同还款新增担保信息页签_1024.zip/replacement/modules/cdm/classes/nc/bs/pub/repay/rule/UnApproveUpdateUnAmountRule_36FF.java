package nc.bs.pub.repay.rule;

import java.util.HashMap;

import nc.bs.framework.common.NCLocator;
import nc.impl.pubapp.pattern.rule.IRule;
import nc.itf.pub.contract.IContractQueryService;
import nc.itf.pub.repay.IRepayReceiptQueryService;
import nc.pubitf.pub.contractiabill.IContIABillQueryService;
import nc.pubitf.pub.payreceipt.IPayReceiptManagerService;
import nc.pubitf.tmpub.settledate.ISettleDateQueryService;
import nc.vo.cdm.repayreceiptbankcredit.RePayReceiptBankCreditBVO;
import nc.vo.pub.BusinessException;
import nc.vo.pub.SuperVO;
import nc.vo.pub.contract.ContractVO;
import nc.vo.pub.ia.IAMaxSettleDateCheckVO;
import nc.vo.pub.lang.UFBoolean;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.pf.BillStatusEnum;
import nc.vo.pub.repay.AggRepayReceiptVO;
import nc.vo.pub.repay.RepayReceiptBVO;
import nc.vo.pub.repay.RepayReceiptVO;
import nc.vo.pubapp.pattern.exception.ExceptionUtils;
import nc.vo.pubapp.pattern.model.entity.bill.IBill;
import nc.vo.tmpub.util.DateUtil;

@SuppressWarnings("rawtypes")
public class UnApproveUpdateUnAmountRule_36FF implements IRule {

	@Override
	public void process(Object[] vos) {
		IBill[] bills = (IBill[]) vos;
		HashMap<String, UFDouble> primaryKeyToUnAmount = new HashMap<String, UFDouble>();
		for (IBill bill : bills) {
			SuperVO[] superVOs = (SuperVO[]) bill
					.getChildren(RePayReceiptBankCreditBVO.class);
			SuperVO parent = (SuperVO) bill.getParent();
			Integer vbillstatus = (Integer) parent
					.getAttributeValue(RepayReceiptVO.VBILLSTATUS);
			if (BillStatusEnum.APPROVED.toIntValue() != vbillstatus) {
				continue;
			}
			String pk_contract = (String) parent
					.getAttributeValue(RepayReceiptVO.PK_CONTRACT);
			UFDate repaydate = (UFDate) parent
					.getAttributeValue(RepayReceiptVO.REPAYDATE);
			String vbillno = (String) parent
					.getAttributeValue(RepayReceiptVO.VBILLNO);
			UFBoolean repayofmai = (UFBoolean) parent
					.getAttributeValue(RepayReceiptVO.REPAYOFMNTANDINT);
			UFDouble repayamount = (UFDouble) parent
					.getAttributeValue(RepayReceiptVO.REPAYAMOUNT);
			String pk_org = (String) parent
				.getAttributeValue(RepayReceiptVO.PK_ORG);
			checkHasRepay(bill);
			checkJxDate(repaydate, pk_contract, vbillno, repayofmai,
					repayamount,pk_org);
			if (superVOs == null || superVOs.length < 1)
				continue;
			for (SuperVO superVO : superVOs) {
				String pk_repayplan = (String) superVO
						.getAttributeValue(RepayReceiptBVO.PK_REPAYPLAN);
				UFDouble payamount = (UFDouble) superVO
						.getAttributeValue(RepayReceiptBVO.REPAYAMOUNT);
				primaryKeyToUnAmount.put(pk_repayplan, payamount);
			}
		}
		if (primaryKeyToUnAmount.isEmpty())
			return;
		this.updateUnAmount(primaryKeyToUnAmount);
	}

	private void updateUnAmount(HashMap<String, UFDouble> primaryKeyToUnAmount) {
		IPayReceiptManagerService managerService = NCLocator.getInstance()
				.lookup(IPayReceiptManagerService.class);
		try {
			managerService.unApproveUpdateUnAmount(primaryKeyToUnAmount);
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
	}

	/**
	 * �жϻ���Ƿ��Ѿ���Ϣ
	 * 
	 * @param repaydate
	 * @param pk_contract
	 * @param vbillno
	 */
	private void checkJxDate(UFDate repaydate, String pk_contract,
			String vbillno, UFBoolean repayofmai, UFDouble repayamount,String pk_org) {
		try {
			IAMaxSettleDateCheckVO iaMaxSettleDateVO = getContIABillQueryService()
					.queryMaxSettleDateVOByContPK(pk_contract);
			UFDate jxdate = null;
			boolean isJXMaxSettleDate = false;
			if (iaMaxSettleDateVO != null) {
				jxdate = iaMaxSettleDateVO.getMaxSettleDate();
				jxdate = DateUtil.convertToOrgUFDate(pk_org, jxdate);
				isJXMaxSettleDate = iaMaxSettleDateVO.isJXSettleDate();
			}
			ContractVO contractVO = getContractQueryService()
					.queryContractMainByPk(pk_contract);
			UFDouble leftrepay = contractVO.getLeftrepayamount();
			UFDouble leftpay = contractVO.getLeftpayamount();
			String pk_settledate = contractVO.getPk_settledate();
			UFDate endDate = contractVO.getEnddate();
			repaydate = DateUtil.convertToOrgUFDate(pk_org, repaydate);
			// ���һ�μ�ϢΪ��ͬ����ǿ�Ƽ�Ϣ
			if (jxdate != null
					&& jxdate.asBegin().compareTo(endDate.getDateBefore(1).asBegin()) == 0
					&& repaydate.compareTo(endDate.asBegin()) >= 0) {
				return;
			}
			boolean isSettledate = false;
			// ���һ�μ�ϢΪ��Ϣ�ռ�Ϣ
			if (pk_settledate != null && !"".equals(pk_settledate)
					&& jxdate != null) {
				UFDate[] settledates = NCLocator
						.getInstance()
						.lookup(ISettleDateQueryService.class)
						.getSettleDates(pk_settledate, contractVO.getPk_org(),
								jxdate, jxdate);
				if (settledates != null && settledates.length > 0) {
					isSettledate = true;
				}
			}
			// ���Ϊ���һ�λ�����������ж���ǰһ��
			boolean mai = false;
			if (repayofmai != null && UFBoolean.TRUE.equals(repayofmai)) {
				mai = true;
			}
			if (!mai && UFDouble.ZERO_DBL.equals(leftrepay)
					&& UFDouble.ZERO_DBL.equals(leftpay) && !isSettledate
					&& repayamount != null
					&& !UFDouble.ZERO_DBL.equals(repayamount) && isJXMaxSettleDate) {
				repaydate = repaydate.getDateBefore(1);
			}
			if (jxdate != null && jxdate.after(repaydate)) {
				ExceptionUtils
						.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
								.getNCLangRes().getStrByID("3615pub_0",
										"03615pub-0582")/* @res "���[" */
								+ vbillno
								+ nc.vo.ml.NCLangRes4VoTransl.getNCLangRes()
										.getStrByID("3615pub_0",
												"03615pub-0583")/*
																 * @res
																 * "]�Ѿ���Ϣ���޷�ȡ��������"
																 */);
			}
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
	}
	/**
	 * �ڴ�֮���Ƿ���ڻ��
	 */
	private void checkHasRepay(IBill bill){
		SuperVO parent = (SuperVO) bill.getParent();
		UFDate repaydate = ((UFDate) parent.getAttributeValue(RepayReceiptVO.REPAYDATE)).asBegin();
		String pk_contract = (String) parent.getAttributeValue(RepayReceiptVO.PK_CONTRACT);
		AggRepayReceiptVO[] aggvos = getAggVOByContract(pk_contract);
		if (aggvos != null) {
			for (AggRepayReceiptVO aggvo : aggvos) {
				RepayReceiptVO repayvo = aggvo.getParentVO();
				if (repayvo.getRepaydate().asBegin().compareTo(repaydate) > 0) {
					ExceptionUtils
							.wrappBusinessException(nc.vo.ml.NCLangRes4VoTransl
									.getNCLangRes().getStrByID("3615pub_0",
											"03615pub-0772")/* @res "�Ѵ��ڻ�����ڸû������ڣ�����" */);
				}
			}
		}
	}
	
	private AggRepayReceiptVO[] getAggVOByContract(String pk_contract){
		AggRepayReceiptVO[] aggvos = null;
		try {
			aggvos = NCLocator.getInstance().lookup(IRepayReceiptQueryService.class).getRepayReceiptVOByContract(pk_contract);
			
		} catch (BusinessException e) {
			ExceptionUtils.wrappException(e);
		}
		if (aggvos != null && aggvos.length > 0) {
			return aggvos;
		}
		return null;
	}

	private IContractQueryService getContractQueryService() {
		return NCLocator.getInstance().lookup(IContractQueryService.class);
	}

	private IContIABillQueryService getContIABillQueryService() {
		IContIABillQueryService contIABillQueryService = NCLocator
				.getInstance().lookup(IContIABillQueryService.class);
		return contIABillQueryService;
	}
}