package nc.bs.pub.action;

import nc.bs.cdm.repayreceiptbankcredit.ace.bp.AceRePayReceiptBankCreditApproveBP;
import nc.bs.cdm.repayreceiptbankcredit.plugin.bpplugin.RePayReceiptBankCreditPluginPoint;
import nc.bs.cdm.repayreceiptbankcredit.rule.RePayRcptBankBookkeptRule;
import nc.bs.pub.repay.rule.ApproveUpdateUnAmountRule_36FF;
import nc.bs.pub.repay.rule.ContractStatusCheckRule;
import nc.bs.pub.repay.rule.InsertContractExecRule_36FF;
import nc.bs.pub.repay.rule.RePayOfAmountAndInterestRule;
import nc.bs.pub.repay.rule.RepayDateCheckRule;
import nc.bs.pub.rule.CDMSendDAPRule;
import nc.bs.pub.rule.CDMSetVoucherFieldRule;
import nc.bs.pub.util.CDMPublicUtil;
import nc.bs.pubapp.pf.action.AbstractPfAction;
import nc.bs.pubapp.pub.rule.ApproveStatusCheckRule;
import nc.impl.pubapp.pattern.rule.IRule;
import nc.impl.pubapp.pattern.rule.processer.CompareAroundProcesser;
import nc.vo.cdm.repayreceiptbankcredit.AggRePayReceiptBankCreditVO;
import nc.vo.cdm.tbb.TbbCommonUtil;
import nc.vo.pub.BusinessException;
import nc.vo.pub.VOStatus;
import nc.vo.pub.lang.UFDate;

public class N_36FF_APPROVE extends
		AbstractPfAction<AggRePayReceiptBankCreditVO> {

	public N_36FF_APPROVE() {
		super();
	}

	@Override
	protected CompareAroundProcesser<AggRePayReceiptBankCreditVO> getCompareAroundProcesserWithRules(
			Object userObj) {
		CompareAroundProcesser<AggRePayReceiptBankCreditVO> processor = new CompareAroundProcesser<AggRePayReceiptBankCreditVO>(
				RePayReceiptBankCreditPluginPoint.APPROVE);
		IRule<AggRePayReceiptBankCreditVO> rule = new ApproveStatusCheckRule();
		IRule<AggRePayReceiptBankCreditVO> contractStatusCheckRule = new ContractStatusCheckRule();
		IRule<AggRePayReceiptBankCreditVO> insertContractExecRule = new InsertContractExecRule_36FF();
		IRule<AggRePayReceiptBankCreditVO> approveUpdateUnAmountRule = new ApproveUpdateUnAmountRule_36FF();
		IRule<AggRePayReceiptBankCreditVO> bookkeptRule = new RePayRcptBankBookkeptRule(
				(String) this.m_tmpVo.getCustomPropertyBatch().get("isForce"));
		IRule<AggRePayReceiptBankCreditVO> sendDapRule = new CDMSendDAPRule();
		IRule<AggRePayReceiptBankCreditVO> repayOfAAIRule = new RePayOfAmountAndInterestRule();
		IRule<AggRePayReceiptBankCreditVO> repayDateCheckRule = new RepayDateCheckRule();

		
		processor.addBeforeRule(rule);
		processor.addBeforeRule(contractStatusCheckRule);
		processor.addAfterRule(repayDateCheckRule);
		processor.addAfterRule(insertContractExecRule);
		processor.addAfterRule(approveUpdateUnAmountRule);
		processor.addAfterRule(repayOfAAIRule);
		processor.addAfterRule(bookkeptRule);
		processor.addAfterRule(sendDapRule);
		return processor;
	}

	@Override
	protected AggRePayReceiptBankCreditVO[] processBP(Object userObj,
			AggRePayReceiptBankCreditVO[] clientFullVOs,
			AggRePayReceiptBankCreditVO[] originBills) {
		String tbbmessage = null;
		if (clientFullVOs != null && clientFullVOs.length > 0) {
			for (int i = 0; i < clientFullVOs.length; i++) {

				clientFullVOs[i].getParentVO().setStatus(VOStatus.UPDATED);
				boolean isEndStep4Audit = CDMPublicUtil
						.isEndStep4Audit(clientFullVOs[i]);
				if (isEndStep4Audit) {
					try {

						tbbmessage = TbbCommonUtil.controlNtb(clientFullVOs[i],
								false, new UFDate());
						clientFullVOs[i].getParentVO().setInteractfield(
								tbbmessage);

					} catch (BusinessException e) {
						throw new RuntimeException(e.getMessage(), e);
					}
				}

			}
			// ��֤ begin
			IRule<AggRePayReceiptBankCreditVO> cdmSetVoucherFieldRule = new CDMSetVoucherFieldRule();
			cdmSetVoucherFieldRule.process(clientFullVOs);
			// ��֤ end
			AggRePayReceiptBankCreditVO[] bills = new AceRePayReceiptBankCreditApproveBP()
					.approve(clientFullVOs, originBills);
			return bills;
		}
		return null;
	}

}
