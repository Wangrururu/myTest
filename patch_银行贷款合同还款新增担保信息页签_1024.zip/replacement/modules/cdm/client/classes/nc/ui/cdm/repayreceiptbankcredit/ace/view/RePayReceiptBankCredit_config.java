package nc.ui.cdm.repayreceiptbankcredit.ace.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nc.ui.uif2.factory.AbstractJavaBeanDefinition;

public class RePayReceiptBankCredit_config extends AbstractJavaBeanDefinition{
	private Map<String, Object> context = new HashMap();
public nc.ui.pubapp.uif2app.view.eventdispatch.Many2ManyDispatcher getEditDispatcher(){
 if(context.get("editDispatcher")!=null)
 return (nc.ui.pubapp.uif2app.view.eventdispatch.Many2ManyDispatcher)context.get("editDispatcher");
  nc.ui.pubapp.uif2app.view.eventdispatch.Many2ManyDispatcher bean = new nc.ui.pubapp.uif2app.view.eventdispatch.Many2ManyDispatcher();
  context.put("editDispatcher",bean);
  bean.setMany2one(getManagedMap0());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private Map getManagedMap0(){  Map map = new HashMap();  map.put(getManagedList0(),getDigitListener());  return map;}

private List getManagedList0(){  List list = new ArrayList();  list.add("pk_currtype");  list.add("pk_org");  list.add("pk_group");  list.add("olcrate");  list.add("glcrate");  list.add("gllcrate");  list.add("repaydate");  list.add("contractamount");  list.add("repayamount");  list.add("apinterest");  list.add("interest");  list.add("sumamount");  list.add("aprepayamount");  list.add("pk_foreigncurr");  list.add("foreignrate");  list.add("foreignamount");  list.add("payreleaseamount");  list.add("pk_procurr");  return list;}

public nc.ui.pubapp.uif2app.view.EditHandleMediator getEditHandleMediator(){
 if(context.get("editHandleMediator")!=null)
 return (nc.ui.pubapp.uif2app.view.EditHandleMediator)context.get("editHandleMediator");
  nc.ui.pubapp.uif2app.view.EditHandleMediator bean = new nc.ui.pubapp.uif2app.view.EditHandleMediator(getBillFormEditor());  context.put("editHandleMediator",bean);
  bean.setDispatcher(getEditDispatcher());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.tmpub.digit.vo.SrcDestItemCollection getSrcDestCollection(){
 if(context.get("srcDestCollection")!=null)
 return (nc.ui.tmpub.digit.vo.SrcDestItemCollection)context.get("srcDestCollection");
  nc.ui.tmpub.digit.vo.SrcDestItemCollection bean = new nc.ui.tmpub.digit.vo.SrcDestItemCollection();
  context.put("srcDestCollection",bean);
  bean.setSrcDestOrigMap(getManagedMap1());
  bean.init();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private Map getManagedMap1(){  Map map = new HashMap();  map.put(getManagedList1(),getManagedList11());  map.put(getManagedList19(),getManagedList29());  map.put(getManagedList38(),getManagedList48());  map.put(getManagedList56(),getManagedList66());  map.put(getManagedList74(),getManagedList84());  map.put(getManagedList92(),getManagedList102());  map.put(getManagedList110(),getManagedList116());  return map;}

private List getManagedList1(){  List list = new ArrayList();  list.add(getManagedList2());  list.add(getManagedList3());  list.add(getManagedList4());  list.add(getManagedList5());  list.add(getManagedList6());  list.add(getManagedList7());  list.add(getManagedList8());  list.add(getManagedList9());  list.add(getManagedList10());  return list;}

private List getManagedList2(){  List list = new ArrayList();  list.add("CURR");  list.add("pk_currtype");  list.add("HEAD");  return list;}

private List getManagedList3(){  List list = new ArrayList();  list.add("ORG");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList4(){  List list = new ArrayList();  list.add("GROUP");  list.add("pk_group");  list.add("HEAD");  return list;}

private List getManagedList5(){  List list = new ArrayList();  list.add("GLOBAL");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList6(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList7(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList8(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList9(){  List list = new ArrayList();  list.add("MONEY");  list.add("repayamount");  list.add("HEAD");  return list;}

private List getManagedList10(){  List list = new ArrayList();  list.add("EXCHANGEDATE");  list.add("repaydate");  list.add("HEAD");  return list;}

private List getManagedList11(){  List list = new ArrayList();  list.add(getManagedList12());  list.add(getManagedList13());  list.add(getManagedList14());  list.add(getManagedList15());  list.add(getManagedList16());  list.add(getManagedList17());  list.add(getManagedList18());  return list;}

private List getManagedList12(){  List list = new ArrayList();  list.add("CURR_MONEY");  list.add("repayamount");  list.add("HEAD");  return list;}

private List getManagedList13(){  List list = new ArrayList();  list.add("ORG_MONEY");  list.add("olcrepayamount");  list.add("HEAD");  return list;}

private List getManagedList14(){  List list = new ArrayList();  list.add("GROUP_MONEY");  list.add("glcrepayamount");  list.add("HEAD");  return list;}

private List getManagedList15(){  List list = new ArrayList();  list.add("GLOBAL_MONEY");  list.add("gllcrepayamount");  list.add("HEAD");  return list;}

private List getManagedList16(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList17(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList18(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList19(){  List list = new ArrayList();  list.add(getManagedList20());  list.add(getManagedList21());  list.add(getManagedList22());  list.add(getManagedList23());  list.add(getManagedList24());  list.add(getManagedList25());  list.add(getManagedList26());  list.add(getManagedList27());  list.add(getManagedList28());  return list;}

private List getManagedList20(){  List list = new ArrayList();  list.add("CURR");  list.add("pk_currtype");  list.add("HEAD");  return list;}

private List getManagedList21(){  List list = new ArrayList();  list.add("ORG");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList22(){  List list = new ArrayList();  list.add("GROUP");  list.add("pk_group");  list.add("HEAD");  return list;}

private List getManagedList23(){  List list = new ArrayList();  list.add("GLOBAL");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList24(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList25(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList26(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList27(){  List list = new ArrayList();  list.add("MONEY");  list.add("apinterest");  list.add("HEAD");  return list;}

private List getManagedList28(){  List list = new ArrayList();  list.add("EXCHANGEDATE");  list.add("repaydate");  list.add("HEAD");  return list;}

private List getManagedList29(){  List list = new ArrayList();  list.add(getManagedList30());  list.add(getManagedList31());  list.add(getManagedList32());  list.add(getManagedList33());  list.add(getManagedList34());  list.add(getManagedList35());  list.add(getManagedList36());  list.add(getManagedList37());  return list;}

private List getManagedList30(){  List list = new ArrayList();  list.add("CURR_MONEY");  list.add("apinterest");  list.add("HEAD");  return list;}

private List getManagedList31(){  List list = new ArrayList();  list.add("CURR_MONEY");  list.add("contractamount");  list.add("HEAD");  return list;}

private List getManagedList32(){  List list = new ArrayList();  list.add("ORG_MONEY");  list.add("olcapinterest");  list.add("HEAD");  return list;}

private List getManagedList33(){  List list = new ArrayList();  list.add("GROUP_MONEY");  list.add("glcapinterest");  list.add("HEAD");  return list;}

private List getManagedList34(){  List list = new ArrayList();  list.add("GLOBAL_MONEY");  list.add("gllcapinterest");  list.add("HEAD");  return list;}

private List getManagedList35(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList36(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList37(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList38(){  List list = new ArrayList();  list.add(getManagedList39());  list.add(getManagedList40());  list.add(getManagedList41());  list.add(getManagedList42());  list.add(getManagedList43());  list.add(getManagedList44());  list.add(getManagedList45());  list.add(getManagedList46());  list.add(getManagedList47());  return list;}

private List getManagedList39(){  List list = new ArrayList();  list.add("CURR");  list.add("pk_currtype");  list.add("HEAD");  return list;}

private List getManagedList40(){  List list = new ArrayList();  list.add("ORG");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList41(){  List list = new ArrayList();  list.add("GROUP");  list.add("pk_group");  list.add("HEAD");  return list;}

private List getManagedList42(){  List list = new ArrayList();  list.add("GLOBAL");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList43(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList44(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList45(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList46(){  List list = new ArrayList();  list.add("MONEY");  list.add("interest");  list.add("HEAD");  return list;}

private List getManagedList47(){  List list = new ArrayList();  list.add("EXCHANGEDATE");  list.add("repaydate");  list.add("HEAD");  return list;}

private List getManagedList48(){  List list = new ArrayList();  list.add(getManagedList49());  list.add(getManagedList50());  list.add(getManagedList51());  list.add(getManagedList52());  list.add(getManagedList53());  list.add(getManagedList54());  list.add(getManagedList55());  return list;}

private List getManagedList49(){  List list = new ArrayList();  list.add("CURR_MONEY");  list.add("interest");  list.add("HEAD");  return list;}

private List getManagedList50(){  List list = new ArrayList();  list.add("ORG_MONEY");  list.add("olcinterest");  list.add("HEAD");  return list;}

private List getManagedList51(){  List list = new ArrayList();  list.add("GROUP_MONEY");  list.add("glcinterest");  list.add("HEAD");  return list;}

private List getManagedList52(){  List list = new ArrayList();  list.add("GLOBAL_MONEY");  list.add("gllcinterest");  list.add("HEAD");  return list;}

private List getManagedList53(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList54(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList55(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList56(){  List list = new ArrayList();  list.add(getManagedList57());  list.add(getManagedList58());  list.add(getManagedList59());  list.add(getManagedList60());  list.add(getManagedList61());  list.add(getManagedList62());  list.add(getManagedList63());  list.add(getManagedList64());  list.add(getManagedList65());  return list;}

private List getManagedList57(){  List list = new ArrayList();  list.add("CURR");  list.add("pk_currtype");  list.add("HEAD");  return list;}

private List getManagedList58(){  List list = new ArrayList();  list.add("ORG");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList59(){  List list = new ArrayList();  list.add("GROUP");  list.add("pk_group");  list.add("HEAD");  return list;}

private List getManagedList60(){  List list = new ArrayList();  list.add("GLOBAL");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList61(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList62(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList63(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList64(){  List list = new ArrayList();  list.add("MONEY");  list.add("sumamount");  list.add("HEAD");  return list;}

private List getManagedList65(){  List list = new ArrayList();  list.add("EXCHANGEDATE");  list.add("repaydate");  list.add("HEAD");  return list;}

private List getManagedList66(){  List list = new ArrayList();  list.add(getManagedList67());  list.add(getManagedList68());  list.add(getManagedList69());  list.add(getManagedList70());  list.add(getManagedList71());  list.add(getManagedList72());  list.add(getManagedList73());  return list;}

private List getManagedList67(){  List list = new ArrayList();  list.add("CURR_MONEY");  list.add("sumamount");  list.add("HEAD");  return list;}

private List getManagedList68(){  List list = new ArrayList();  list.add("ORG_MONEY");  list.add("olcsumamount");  list.add("HEAD");  return list;}

private List getManagedList69(){  List list = new ArrayList();  list.add("GROUP_MONEY");  list.add("glcsumamount");  list.add("HEAD");  return list;}

private List getManagedList70(){  List list = new ArrayList();  list.add("GLOBAL_MONEY");  list.add("gllcsumamount");  list.add("HEAD");  return list;}

private List getManagedList71(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList72(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList73(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList74(){  List list = new ArrayList();  list.add(getManagedList75());  list.add(getManagedList76());  list.add(getManagedList77());  list.add(getManagedList78());  list.add(getManagedList79());  list.add(getManagedList80());  list.add(getManagedList81());  list.add(getManagedList82());  list.add(getManagedList83());  return list;}

private List getManagedList75(){  List list = new ArrayList();  list.add("CURR");  list.add("pk_currtype");  list.add("HEAD");  return list;}

private List getManagedList76(){  List list = new ArrayList();  list.add("ORG");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList77(){  List list = new ArrayList();  list.add("GROUP");  list.add("pk_group");  list.add("HEAD");  return list;}

private List getManagedList78(){  List list = new ArrayList();  list.add("GLOBAL");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList79(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList80(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList81(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList82(){  List list = new ArrayList();  list.add("MONEY");  list.add("repayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList83(){  List list = new ArrayList();  list.add("EXCHANGEDATE");  list.add("repaydate");  list.add("HEAD");  return list;}

private List getManagedList84(){  List list = new ArrayList();  list.add(getManagedList85());  list.add(getManagedList86());  list.add(getManagedList87());  list.add(getManagedList88());  list.add(getManagedList89());  list.add(getManagedList90());  list.add(getManagedList91());  return list;}

private List getManagedList85(){  List list = new ArrayList();  list.add("CURR_MONEY");  list.add("repayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList86(){  List list = new ArrayList();  list.add("ORG_MONEY");  list.add("olcrepayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList87(){  List list = new ArrayList();  list.add("GROUP_MONEY");  list.add("glcrepayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList88(){  List list = new ArrayList();  list.add("GLOBAL_MONEY");  list.add("gllcrepayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList89(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList90(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList91(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList92(){  List list = new ArrayList();  list.add(getManagedList93());  list.add(getManagedList94());  list.add(getManagedList95());  list.add(getManagedList96());  list.add(getManagedList97());  list.add(getManagedList98());  list.add(getManagedList99());  list.add(getManagedList100());  list.add(getManagedList101());  return list;}

private List getManagedList93(){  List list = new ArrayList();  list.add("CURR");  list.add("pk_currtype");  list.add("HEAD");  return list;}

private List getManagedList94(){  List list = new ArrayList();  list.add("ORG");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList95(){  List list = new ArrayList();  list.add("GROUP");  list.add("pk_group");  list.add("HEAD");  return list;}

private List getManagedList96(){  List list = new ArrayList();  list.add("GLOBAL");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList97(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList98(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList99(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList100(){  List list = new ArrayList();  list.add("MONEY");  list.add("aprepayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList101(){  List list = new ArrayList();  list.add("EXCHANGEDATE");  list.add("repaydate");  list.add("HEAD");  return list;}

private List getManagedList102(){  List list = new ArrayList();  list.add(getManagedList103());  list.add(getManagedList104());  list.add(getManagedList105());  list.add(getManagedList106());  list.add(getManagedList107());  list.add(getManagedList108());  list.add(getManagedList109());  return list;}

private List getManagedList103(){  List list = new ArrayList();  list.add("CURR_MONEY");  list.add("aprepayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList104(){  List list = new ArrayList();  list.add("ORG_MONEY");  list.add("olcaprepayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList105(){  List list = new ArrayList();  list.add("GROUP_MONEY");  list.add("glcaprepayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList106(){  List list = new ArrayList();  list.add("GLOBAL_MONEY");  list.add("gllcaprepayamount");  list.add("BODY");  list.add("repayrcptsub");  return list;}

private List getManagedList107(){  List list = new ArrayList();  list.add("ORG_RATE");  list.add("olcrate");  list.add("HEAD");  return list;}

private List getManagedList108(){  List list = new ArrayList();  list.add("GROUP_RATE");  list.add("glcrate");  list.add("HEAD");  return list;}

private List getManagedList109(){  List list = new ArrayList();  list.add("GLOBAL_RATE");  list.add("gllcrate");  list.add("HEAD");  return list;}

private List getManagedList110(){  List list = new ArrayList();  list.add(getManagedList111());  list.add(getManagedList112());  list.add(getManagedList113());  list.add(getManagedList114());  list.add(getManagedList115());  return list;}

private List getManagedList111(){  List list = new ArrayList();  list.add("CURR");  list.add("pk_procurr");  list.add("HEAD");  return list;}

private List getManagedList112(){  List list = new ArrayList();  list.add("ORG");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList113(){  List list = new ArrayList();  list.add("GROUP");  list.add("pk_group");  list.add("HEAD");  return list;}

private List getManagedList114(){  List list = new ArrayList();  list.add("GLOBAL");  list.add("pk_org");  list.add("HEAD");  return list;}

private List getManagedList115(){  List list = new ArrayList();  list.add("MONEY");  list.add("payreleaseamount");  list.add("HEAD");  return list;}

private List getManagedList116(){  List list = new ArrayList();  list.add(getManagedList117());  return list;}

private List getManagedList117(){  List list = new ArrayList();  list.add("CURR_MONEY");  list.add("payreleaseamount");  list.add("HEAD");  return list;}

public nc.ui.pubapp.uif2app.model.AppEventHandlerMediator getDigitMediator(){
 if(context.get("digitMediator")!=null)
 return (nc.ui.pubapp.uif2app.model.AppEventHandlerMediator)context.get("digitMediator");
  nc.ui.pubapp.uif2app.model.AppEventHandlerMediator bean = new nc.ui.pubapp.uif2app.model.AppEventHandlerMediator();
  context.put("digitMediator",bean);
  bean.setModel(getManageAppModel());
  bean.setHandlerMap(getManagedMap2());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private Map getManagedMap2(){  Map map = new HashMap();  map.put("nc.ui.pubapp.uif2app.event.list.ListPanelLoadEvent",getManagedList118());  map.put("nc.ui.pubapp.uif2app.event.card.CardPanelLoadEvent",getManagedList120());  map.put("nc.ui.uif2.AppEvent",getManagedList122());  return map;}

private List getManagedList118(){  List list = new ArrayList();  list.add(getListPanelLoadDigitListener_1426b22());  return list;}

private nc.ui.tmpub.digit.listener.list.ListPanelLoadDigitListener getListPanelLoadDigitListener_1426b22(){
 if(context.get("nc.ui.tmpub.digit.listener.list.ListPanelLoadDigitListener#1426b22")!=null)
 return (nc.ui.tmpub.digit.listener.list.ListPanelLoadDigitListener)context.get("nc.ui.tmpub.digit.listener.list.ListPanelLoadDigitListener#1426b22");
  nc.ui.tmpub.digit.listener.list.ListPanelLoadDigitListener bean = new nc.ui.tmpub.digit.listener.list.ListPanelLoadDigitListener();
  context.put("nc.ui.tmpub.digit.listener.list.ListPanelLoadDigitListener#1426b22",bean);
  bean.setSrcDestItemCollection(getSrcDestCollection());
  bean.setSelfDefListeners(getManagedList119());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList119(){  List list = new ArrayList();  list.add(getCDMListDefDecimalListener_1dcd3c6());  list.add(getCDMListDefDecimalListener_d37760());  return list;}

private nc.ui.pub.repay.digit.CDMListDefDecimalListener getCDMListDefDecimalListener_1dcd3c6(){
 if(context.get("nc.ui.pub.repay.digit.CDMListDefDecimalListener#1dcd3c6")!=null)
 return (nc.ui.pub.repay.digit.CDMListDefDecimalListener)context.get("nc.ui.pub.repay.digit.CDMListDefDecimalListener#1dcd3c6");
  nc.ui.pub.repay.digit.CDMListDefDecimalListener bean = new nc.ui.pub.repay.digit.CDMListDefDecimalListener();
  context.put("nc.ui.pub.repay.digit.CDMListDefDecimalListener#1dcd3c6",bean);
  bean.setModel(getManageAppModel());
  bean.setSourceKey("foreignamount");
  bean.setInCurrKey("pk_currtype");
  bean.setOutCurrKey("pk_foreigncurr");
  bean.setItemType("amount");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pub.repay.digit.CDMListDefDecimalListener getCDMListDefDecimalListener_d37760(){
 if(context.get("nc.ui.pub.repay.digit.CDMListDefDecimalListener#d37760")!=null)
 return (nc.ui.pub.repay.digit.CDMListDefDecimalListener)context.get("nc.ui.pub.repay.digit.CDMListDefDecimalListener#d37760");
  nc.ui.pub.repay.digit.CDMListDefDecimalListener bean = new nc.ui.pub.repay.digit.CDMListDefDecimalListener();
  context.put("nc.ui.pub.repay.digit.CDMListDefDecimalListener#d37760",bean);
  bean.setModel(getManageAppModel());
  bean.setSourceKey("foreignrate");
  bean.setInCurrKey("pk_currtype");
  bean.setOutCurrKey("pk_foreigncurr");
  bean.setItemType("rate");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList120(){  List list = new ArrayList();  list.add(getCardPanelLoadDigitListener_11e2ee());  return list;}

private nc.ui.tmpub.digit.listener.card.CardPanelLoadDigitListener getCardPanelLoadDigitListener_11e2ee(){
 if(context.get("nc.ui.tmpub.digit.listener.card.CardPanelLoadDigitListener#11e2ee")!=null)
 return (nc.ui.tmpub.digit.listener.card.CardPanelLoadDigitListener)context.get("nc.ui.tmpub.digit.listener.card.CardPanelLoadDigitListener#11e2ee");
  nc.ui.tmpub.digit.listener.card.CardPanelLoadDigitListener bean = new nc.ui.tmpub.digit.listener.card.CardPanelLoadDigitListener();
  context.put("nc.ui.tmpub.digit.listener.card.CardPanelLoadDigitListener#11e2ee",bean);
  bean.setSrcDestItemCollection(getSrcDestCollection());
  bean.setSelfDefListeners(getManagedList121());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList121(){  List list = new ArrayList();  list.add(getCDMCardDefDecimalListener_18788e7());  list.add(getCDMCardDefDecimalListener_12d02c9());  return list;}

private nc.ui.pub.repay.digit.CDMCardDefDecimalListener getCDMCardDefDecimalListener_18788e7(){
 if(context.get("nc.ui.pub.repay.digit.CDMCardDefDecimalListener#18788e7")!=null)
 return (nc.ui.pub.repay.digit.CDMCardDefDecimalListener)context.get("nc.ui.pub.repay.digit.CDMCardDefDecimalListener#18788e7");
  nc.ui.pub.repay.digit.CDMCardDefDecimalListener bean = new nc.ui.pub.repay.digit.CDMCardDefDecimalListener();
  context.put("nc.ui.pub.repay.digit.CDMCardDefDecimalListener#18788e7",bean);
  bean.setModel(getManageAppModel());
  bean.setSourceKey("foreignamount");
  bean.setInCurrKey("pk_currtype");
  bean.setOutCurrKey("pk_foreigncurr");
  bean.setItemType("amount");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pub.repay.digit.CDMCardDefDecimalListener getCDMCardDefDecimalListener_12d02c9(){
 if(context.get("nc.ui.pub.repay.digit.CDMCardDefDecimalListener#12d02c9")!=null)
 return (nc.ui.pub.repay.digit.CDMCardDefDecimalListener)context.get("nc.ui.pub.repay.digit.CDMCardDefDecimalListener#12d02c9");
  nc.ui.pub.repay.digit.CDMCardDefDecimalListener bean = new nc.ui.pub.repay.digit.CDMCardDefDecimalListener();
  context.put("nc.ui.pub.repay.digit.CDMCardDefDecimalListener#12d02c9",bean);
  bean.setModel(getManageAppModel());
  bean.setSourceKey("foreignrate");
  bean.setInCurrKey("pk_currtype");
  bean.setOutCurrKey("pk_foreigncurr");
  bean.setItemType("rate");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList122(){  List list = new ArrayList();  list.add(getCardPanelSelectionChangedListener_4988bb());  return list;}

private nc.ui.tmpub.digit.listener.card.CardPanelSelectionChangedListener getCardPanelSelectionChangedListener_4988bb(){
 if(context.get("nc.ui.tmpub.digit.listener.card.CardPanelSelectionChangedListener#4988bb")!=null)
 return (nc.ui.tmpub.digit.listener.card.CardPanelSelectionChangedListener)context.get("nc.ui.tmpub.digit.listener.card.CardPanelSelectionChangedListener#4988bb");
  nc.ui.tmpub.digit.listener.card.CardPanelSelectionChangedListener bean = new nc.ui.tmpub.digit.listener.card.CardPanelSelectionChangedListener(getBillFormEditor(),getSrcDestCollection());  context.put("nc.ui.tmpub.digit.listener.card.CardPanelSelectionChangedListener#4988bb",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.repay.listener.CalculatorEditListener getDigitListener(){
 if(context.get("digitListener")!=null)
 return (nc.ui.pub.repay.listener.CalculatorEditListener)context.get("digitListener");
  nc.ui.pub.repay.listener.CalculatorEditListener bean = new nc.ui.pub.repay.listener.CalculatorEditListener();
  context.put("digitListener",bean);
  bean.setSrcDestItemCollection(getSrcDestCollection());
  bean.setModel(getManageAppModel());
  bean.setBillForm(getBillFormEditor());
  bean.setAfterCalculators(getManagedList123());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList123(){  List list = new ArrayList();  list.add(getForeignamountCalculator());  return list;}

public nc.ui.pub.repay.calculator.RePayDiffCalculator getForeignamountCalculator(){
 if(context.get("foreignamountCalculator")!=null)
 return (nc.ui.pub.repay.calculator.RePayDiffCalculator)context.get("foreignamountCalculator");
  nc.ui.pub.repay.calculator.RePayDiffCalculator bean = new nc.ui.pub.repay.calculator.RePayDiffCalculator();
  context.put("foreignamountCalculator",bean);
  bean.setBillForm(getBillFormEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.funcnode.ui.action.GroupAction getCard_printMenuAction(){
 if(context.get("card_printMenuAction")!=null)
 return (nc.funcnode.ui.action.GroupAction)context.get("card_printMenuAction");
  nc.funcnode.ui.action.GroupAction bean = new nc.funcnode.ui.action.GroupAction();
  context.put("card_printMenuAction",bean);
  bean.setCode("printgroup");
  bean.setActions(getManagedList124());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList124(){  List list = new ArrayList();  list.add(getCard_templatePrint());  list.add(getCard_templatePreview());  list.add(getCard_outputAction());  return list;}

public nc.ui.uif2.actions.TemplatePreviewAction getCard_templatePreview(){
 if(context.get("card_templatePreview")!=null)
 return (nc.ui.uif2.actions.TemplatePreviewAction)context.get("card_templatePreview");
  nc.ui.uif2.actions.TemplatePreviewAction bean = new nc.ui.uif2.actions.TemplatePreviewAction();
  context.put("card_templatePreview",bean);
  bean.setModel(getManageAppModel());
  bean.setNodeKey("applycard");
  bean.setDatasource(getSingleDataSource());
  bean.setPrintDlgParentConatiner(getBillFormEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.actions.TemplatePrintAction getCard_templatePrint(){
 if(context.get("card_templatePrint")!=null)
 return (nc.ui.uif2.actions.TemplatePrintAction)context.get("card_templatePrint");
  nc.ui.uif2.actions.TemplatePrintAction bean = new nc.ui.uif2.actions.TemplatePrintAction();
  context.put("card_templatePrint",bean);
  bean.setModel(getManageAppModel());
  bean.setNodeKey("applycard");
  bean.setDatasource(getSingleDataSource());
  bean.setPrintDlgParentConatiner(getBillFormEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.actions.OutputAction getCard_outputAction(){
 if(context.get("card_outputAction")!=null)
 return (nc.ui.uif2.actions.OutputAction)context.get("card_outputAction");
  nc.ui.uif2.actions.OutputAction bean = new nc.ui.uif2.actions.OutputAction();
  context.put("card_outputAction",bean);
  bean.setModel(getManageAppModel());
  bean.setNodeKey("applycard");
  bean.setDatasource(getSingleDataSource());
  bean.setPrintDlgParentConatiner(getBillFormEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.tmpub.action.cardprint.MetaDataSingleSelectDataSource getSingleDataSource(){
 if(context.get("singleDataSource")!=null)
 return (nc.ui.tmpub.action.cardprint.MetaDataSingleSelectDataSource)context.get("singleDataSource");
  nc.ui.tmpub.action.cardprint.MetaDataSingleSelectDataSource bean = new nc.ui.tmpub.action.cardprint.MetaDataSingleSelectDataSource();
  context.put("singleDataSource",bean);
  bean.setModel(getManageAppModel());
  bean.setBeforePrintDataProcess(getPrintProcessor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.funcnode.ui.action.GroupAction getList_printMenuAction(){
 if(context.get("list_printMenuAction")!=null)
 return (nc.funcnode.ui.action.GroupAction)context.get("list_printMenuAction");
  nc.funcnode.ui.action.GroupAction bean = new nc.funcnode.ui.action.GroupAction();
  context.put("list_printMenuAction",bean);
  bean.setCode("printgroup");
  bean.setActions(getManagedList125());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList125(){  List list = new ArrayList();  list.add(getList_templetprint_action());  list.add(getList_preview_action());  list.add(getList_output_action());  list.add(getSeparatorAction());  list.add(getPrintPreviewBillCardAction());  return list;}

public nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction getList_templetprint_action(){
 if(context.get("list_templetprint_action")!=null)
 return (nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction)context.get("list_templetprint_action");
  nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction bean = new nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction();
  context.put("list_templetprint_action",bean);
  bean.setPreview(false);
  bean.setModel(getManageAppModel());
  bean.setNodeKey("applycard");
  bean.setBeforePrintDataProcess(getPrintProcessor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction getList_preview_action(){
 if(context.get("list_preview_action")!=null)
 return (nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction)context.get("list_preview_action");
  nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction bean = new nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction();
  context.put("list_preview_action",bean);
  bean.setPreview(true);
  bean.setModel(getManageAppModel());
  bean.setNodeKey("applycard");
  bean.setBeforePrintDataProcess(getPrintProcessor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.OutputAction getList_output_action(){
 if(context.get("list_output_action")!=null)
 return (nc.ui.pubapp.uif2app.actions.OutputAction)context.get("list_output_action");
  nc.ui.pubapp.uif2app.actions.OutputAction bean = new nc.ui.pubapp.uif2app.actions.OutputAction();
  context.put("list_output_action",bean);
  bean.setModel(getManageAppModel());
  bean.setNodeKey("applycard");
  bean.setParent(getBillFormEditor());
  bean.setBeforePrintDataProcess(getPrintProcessor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.tmpub.action.listprint.DefaultTemplatePagePrintFactory getPrintFactory(){
 if(context.get("printFactory")!=null)
 return (nc.ui.tmpub.action.listprint.DefaultTemplatePagePrintFactory)context.get("printFactory");
  nc.ui.tmpub.action.listprint.DefaultTemplatePagePrintFactory bean = new nc.ui.tmpub.action.listprint.DefaultTemplatePagePrintFactory();
  context.put("printFactory",bean);
  bean.setMdId("5122f559-f635-4628-8654-b2d4c06dd0be");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.tmpub.action.listprint.TemplatePaginationPrintAction getPrintBillCardAction(){
 if(context.get("printBillCardAction")!=null)
 return (nc.ui.tmpub.action.listprint.TemplatePaginationPrintAction)context.get("printBillCardAction");
  nc.ui.tmpub.action.listprint.TemplatePaginationPrintAction bean = new nc.ui.tmpub.action.listprint.TemplatePaginationPrintAction();
  context.put("printBillCardAction",bean);
  bean.setModel(getManageAppModel());
  bean.setNodeKey("applylist");
  bean.setPrintFactory(getPrintFactory());
  bean.setPaginationModel(getPaginationModel());
  bean.setPrintDlgParentConatiner(getListView());
  bean.setBeforePrintDataProcess(getPrintProcessor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.tmpub.action.listprint.TemplatePaginationPreviewAction getPrintPreviewBillCardAction(){
 if(context.get("printPreviewBillCardAction")!=null)
 return (nc.ui.tmpub.action.listprint.TemplatePaginationPreviewAction)context.get("printPreviewBillCardAction");
  nc.ui.tmpub.action.listprint.TemplatePaginationPreviewAction bean = new nc.ui.tmpub.action.listprint.TemplatePaginationPreviewAction();
  context.put("printPreviewBillCardAction",bean);
  bean.setPrintAction(getPrintBillCardAction());
  bean.setNodeKey("applylist");
  bean.setBtnName(getI18nFB_68b19a());
  bean.setCode("billprint");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private java.lang.String getI18nFB_68b19a(){
 if(context.get("nc.ui.uif2.I18nFB#68b19a")!=null)
 return (java.lang.String)context.get("nc.ui.uif2.I18nFB#68b19a");
  nc.ui.uif2.I18nFB bean = new nc.ui.uif2.I18nFB();
    context.put("&nc.ui.uif2.I18nFB#68b19a",bean);  bean.setResDir("3634aiac_0");
  bean.setDefaultValue("��ӡ�嵥");
  bean.setResId("03634aiac-0251");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
 try {
     Object product = bean.getObject();
    context.put("nc.ui.uif2.I18nFB#68b19a",product);
     return (java.lang.String)product;
}
catch(Exception e) { throw new RuntimeException(e);}}

public nc.ui.tmpub.digit.print.DefaultPrintProcessor4Rate getPrintProcessor(){
 if(context.get("printProcessor")!=null)
 return (nc.ui.tmpub.digit.print.DefaultPrintProcessor4Rate)context.get("printProcessor");
  nc.ui.tmpub.digit.print.DefaultPrintProcessor4Rate bean = new nc.ui.tmpub.digit.print.DefaultPrintProcessor4Rate();
  context.put("printProcessor",bean);
  bean.setSrcDestItemCollection(getSrcDestCollection());
  bean.setRateMap(getManagedMap3());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private Map getManagedMap3(){  Map map = new HashMap();  map.put(getManagedList126(),getManagedList128());  return map;}

private List getManagedList126(){  List list = new ArrayList();  list.add(getManagedList127());  return list;}

private List getManagedList127(){  List list = new ArrayList();  list.add("RATE");  list.add("rate_key");  list.add("HEAD");  return list;}

private List getManagedList128(){  List list = new ArrayList();  list.add(getManagedList129());  return list;}

private List getManagedList129(){  List list = new ArrayList();  list.add("RATE");  list.add("yrate");  list.add("HEAD");  return list;}

public nc.vo.uif2.LoginContext getContext(){
 if(context.get("context")!=null)
 return (nc.vo.uif2.LoginContext)context.get("context");
  nc.vo.uif2.LoginContext bean = new nc.vo.uif2.LoginContext();
  context.put("context",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.cdm.repayreceiptbankcredit.ace.serviceproxy.AceRePayReceiptBankCreditMaintainProxy getMaintainProxy(){
 if(context.get("maintainProxy")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.ace.serviceproxy.AceRePayReceiptBankCreditMaintainProxy)context.get("maintainProxy");
  nc.ui.cdm.repayreceiptbankcredit.ace.serviceproxy.AceRePayReceiptBankCreditMaintainProxy bean = new nc.ui.cdm.repayreceiptbankcredit.ace.serviceproxy.AceRePayReceiptBankCreditMaintainProxy();
  context.put("maintainProxy",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.view.value.AggVOMetaBDObjectAdapterFactory getBoadatorfactory(){
 if(context.get("boadatorfactory")!=null)
 return (nc.ui.pubapp.uif2app.view.value.AggVOMetaBDObjectAdapterFactory)context.get("boadatorfactory");
  nc.ui.pubapp.uif2app.view.value.AggVOMetaBDObjectAdapterFactory bean = new nc.ui.pubapp.uif2app.view.value.AggVOMetaBDObjectAdapterFactory();
  context.put("boadatorfactory",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.model.BillManageModel getManageAppModel(){
 if(context.get("manageAppModel")!=null)
 return (nc.ui.pubapp.uif2app.model.BillManageModel)context.get("manageAppModel");
  nc.ui.pubapp.uif2app.model.BillManageModel bean = new nc.ui.pubapp.uif2app.model.BillManageModel();
  context.put("manageAppModel",bean);
  bean.setBusinessObjectAdapterFactory(getBoadatorfactory());
  bean.setContext(getContext());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.Action.LinkMenuAction getLinkMenuAction(){
 if(context.get("linkMenuAction")!=null)
 return (nc.ui.pub.Action.LinkMenuAction)context.get("linkMenuAction");
  nc.ui.pub.Action.LinkMenuAction bean = new nc.ui.pub.Action.LinkMenuAction();
  context.put("linkMenuAction",bean);
  bean.setActions(getManagedList130());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList130(){  List list = new ArrayList();  list.add(getContractlinkQueryAction());  list.add(getRePayRcptBankCreditLQueryVoucherAction());  list.add(getRePayRcptBankCreditLQueryBudgetPlanAction());  return list;}

public nc.ui.pubapp.uif2app.model.pagination.PaginationModelDataManager getModelDataManager(){
 if(context.get("modelDataManager")!=null)
 return (nc.ui.pubapp.uif2app.model.pagination.PaginationModelDataManager)context.get("modelDataManager");
  nc.ui.pubapp.uif2app.model.pagination.PaginationModelDataManager bean = new nc.ui.pubapp.uif2app.model.pagination.PaginationModelDataManager();
  context.put("modelDataManager",bean);
  bean.setModel(getManageAppModel());
  bean.setPaginationModel(getPaginationModel());
  bean.setPageQueryService(getPageQueryService());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.model.pagination.PubPaginationModel getPaginationModel(){
 if(context.get("paginationModel")!=null)
 return (nc.ui.pubapp.uif2app.model.pagination.PubPaginationModel)context.get("paginationModel");
  nc.ui.pubapp.uif2app.model.pagination.PubPaginationModel bean = new nc.ui.pubapp.uif2app.model.pagination.PubPaginationModel();
  context.put("paginationModel",bean);
  bean.setPaginationQueryService(getMaintainProxy());
  bean.init();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.funcnode.ui.action.GroupAction getVoucherActionGroup(){
 if(context.get("VoucherActionGroup")!=null)
 return (nc.funcnode.ui.action.GroupAction)context.get("VoucherActionGroup");
  nc.funcnode.ui.action.GroupAction bean = new nc.funcnode.ui.action.GroupAction();
  context.put("VoucherActionGroup",bean);
  bean.setActions(getManagedList131());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList131(){  List list = new ArrayList();  list.add(getVoucherAction());  list.add(getCancelVoucherAction());  return list;}

public nc.ui.pub.repay.action.RePayReceiptVoucherAction getVoucherAction(){
 if(context.get("voucherAction")!=null)
 return (nc.ui.pub.repay.action.RePayReceiptVoucherAction)context.get("voucherAction");
  nc.ui.pub.repay.action.RePayReceiptVoucherAction bean = new nc.ui.pub.repay.action.RePayReceiptVoucherAction();
  context.put("voucherAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setBillType("36FF");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.repay.action.RePayReceiptCancelVoucherAction getCancelVoucherAction(){
 if(context.get("cancelVoucherAction")!=null)
 return (nc.ui.pub.repay.action.RePayReceiptCancelVoucherAction)context.get("cancelVoucherAction");
  nc.ui.pub.repay.action.RePayReceiptCancelVoucherAction bean = new nc.ui.pub.repay.action.RePayReceiptCancelVoucherAction();
  context.put("cancelVoucherAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setBillType("36FF");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.Action.CDMBaseVoucherQueryAction getRePayRcptBankCreditLQueryVoucherAction(){
 if(context.get("rePayRcptBankCreditLQueryVoucherAction")!=null)
 return (nc.ui.pub.Action.CDMBaseVoucherQueryAction)context.get("rePayRcptBankCreditLQueryVoucherAction");
  nc.ui.pub.Action.CDMBaseVoucherQueryAction bean = new nc.ui.pub.Action.CDMBaseVoucherQueryAction("rePayRcptBankCreditLQueryVoucher");  context.put("rePayRcptBankCreditLQueryVoucherAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setListview(getListView());
  bean.setPos(0);
  bean.setLoginContext(getContext());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.cdm.pub.action.CDMBasePlanQueryAction getRePayRcptBankCreditLQueryBudgetPlanAction(){
 if(context.get("rePayRcptBankCreditLQueryBudgetPlanAction")!=null)
 return (nc.ui.cdm.pub.action.CDMBasePlanQueryAction)context.get("rePayRcptBankCreditLQueryBudgetPlanAction");
  nc.ui.cdm.pub.action.CDMBasePlanQueryAction bean = new nc.ui.cdm.pub.action.CDMBasePlanQueryAction("rePayRcptBankCreditLQueryBudgetPlan");  context.put("rePayRcptBankCreditLQueryBudgetPlanAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setListview(getListView());
  bean.setPos(0);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.model.pagination.UIPageQueryService getPageQueryService(){
 if(context.get("pageQueryService")!=null)
 return (nc.ui.pubapp.uif2app.model.pagination.UIPageQueryService)context.get("pageQueryService");
  nc.ui.pubapp.uif2app.model.pagination.UIPageQueryService bean = new nc.ui.pubapp.uif2app.model.pagination.UIPageQueryService();
  context.put("pageQueryService",bean);
  bean.setAllPagePkQueryServiceMethod("nc.itf.cdm.repayreceiptbankcredit.IRePayReceiptBankCreditQueryService.queryByPageQueryScheme");
  bean.setDataOfPksQueryServiceMethod("nc.itf.cdm.repayreceiptbankcredit.IRePayReceiptBankCreditQueryService.queryBillsByPks");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.components.pagination.PaginationBar getPaginationBar(){
 if(context.get("paginationBar")!=null)
 return (nc.ui.uif2.components.pagination.PaginationBar)context.get("paginationBar");
  nc.ui.uif2.components.pagination.PaginationBar bean = new nc.ui.uif2.components.pagination.PaginationBar(2);  context.put("paginationBar",bean);
  bean.setPaginationModel(getPaginationModel());
  bean.setContext(getContext());
  bean.registeCallbak();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.view.TemplateContainer getTemplateContainer(){
 if(context.get("templateContainer")!=null)
 return (nc.ui.pubapp.uif2app.view.TemplateContainer)context.get("templateContainer");
  nc.ui.pubapp.uif2app.view.TemplateContainer bean = new nc.ui.pubapp.uif2app.view.TemplateContainer();
  context.put("templateContainer",bean);
  bean.setContext(getContext());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.editor.QueryTemplateContainer getQueryTemplateContainer(){
 if(context.get("queryTemplateContainer")!=null)
 return (nc.ui.uif2.editor.QueryTemplateContainer)context.get("queryTemplateContainer");
  nc.ui.uif2.editor.QueryTemplateContainer bean = new nc.ui.uif2.editor.QueryTemplateContainer();
  context.put("queryTemplateContainer",bean);
  bean.setContext(getContext());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.repay.view.ShowUpableBillListView getListView(){
 if(context.get("listView")!=null)
 return (nc.ui.pub.repay.view.ShowUpableBillListView)context.get("listView");
  nc.ui.pub.repay.view.ShowUpableBillListView bean = new nc.ui.pub.repay.view.ShowUpableBillListView();
  context.put("listView",bean);
  bean.setPaginationBar(getPaginationBar());
  bean.setModel(getManageAppModel());
  bean.setTemplateContainer(getTemplateContainer());
  bean.setShowTotalLine(true);
  bean.setShowTotalLineTabcodes(getManagedList132());
  bean.setUserdefitemListPreparator(getCompositeBillListDataPrepare_163ffed());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList132(){  List list = new ArrayList();  list.add("repayrcptsub");  return list;}

private nc.ui.pubapp.uif2app.view.CompositeBillListDataPrepare getCompositeBillListDataPrepare_163ffed(){
 if(context.get("nc.ui.pubapp.uif2app.view.CompositeBillListDataPrepare#163ffed")!=null)
 return (nc.ui.pubapp.uif2app.view.CompositeBillListDataPrepare)context.get("nc.ui.pubapp.uif2app.view.CompositeBillListDataPrepare#163ffed");
  nc.ui.pubapp.uif2app.view.CompositeBillListDataPrepare bean = new nc.ui.pubapp.uif2app.view.CompositeBillListDataPrepare();
  context.put("nc.ui.pubapp.uif2app.view.CompositeBillListDataPrepare#163ffed",bean);
  bean.setBillListDataPrepares(getManagedList133());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList133(){  List list = new ArrayList();  list.add(getUserdefitemlistPreparator());  list.add(getMarAsstPreparator());  return list;}

public nc.ui.uif2.editor.UserdefitemContainerListPreparator getUserdefitemlistPreparator(){
 if(context.get("userdefitemlistPreparator")!=null)
 return (nc.ui.uif2.editor.UserdefitemContainerListPreparator)context.get("userdefitemlistPreparator");
  nc.ui.uif2.editor.UserdefitemContainerListPreparator bean = new nc.ui.uif2.editor.UserdefitemContainerListPreparator();
  context.put("userdefitemlistPreparator",bean);
  bean.setContainer(getUserdefitemContainer());
  bean.setParams(getManagedList134());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList134(){  List list = new ArrayList();  list.add(getUserdefQueryParam_37549c());  list.add(getUserdefQueryParam_93d1fa());  return list;}

private nc.ui.uif2.editor.UserdefQueryParam getUserdefQueryParam_37549c(){
 if(context.get("nc.ui.uif2.editor.UserdefQueryParam#37549c")!=null)
 return (nc.ui.uif2.editor.UserdefQueryParam)context.get("nc.ui.uif2.editor.UserdefQueryParam#37549c");
  nc.ui.uif2.editor.UserdefQueryParam bean = new nc.ui.uif2.editor.UserdefQueryParam();
  context.put("nc.ui.uif2.editor.UserdefQueryParam#37549c",bean);
  bean.setMdfullname("cdm.RePayRcptBankCredit");
  bean.setPos(0);
  bean.setPrefix("vdef");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.editor.UserdefQueryParam getUserdefQueryParam_93d1fa(){
 if(context.get("nc.ui.uif2.editor.UserdefQueryParam#93d1fa")!=null)
 return (nc.ui.uif2.editor.UserdefQueryParam)context.get("nc.ui.uif2.editor.UserdefQueryParam#93d1fa");
  nc.ui.uif2.editor.UserdefQueryParam bean = new nc.ui.uif2.editor.UserdefQueryParam();
  context.put("nc.ui.uif2.editor.UserdefQueryParam#93d1fa",bean);
  bean.setMdfullname("cdm.RePayRcptBankCreditSub");
  bean.setPos(1);
  bean.setPrefix("vdef");
  bean.setTabcode("repayrcptsub");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.repay.view.BillFormEditor getBillFormEditor(){
 if(context.get("billFormEditor")!=null)
 return (nc.ui.pub.repay.view.BillFormEditor)context.get("billFormEditor");
  nc.ui.pub.repay.view.BillFormEditor bean = new nc.ui.pub.repay.view.BillFormEditor();
  context.put("billFormEditor",bean);
  bean.setModel(getManageAppModel());
  bean.setTemplateContainer(getTemplateContainer());
  bean.setShowOrgPanel(true);
  bean.setAutoAddLine(false);
  bean.setBodyLineActions(getManagedList135());
  bean.setUserdefitemPreparator(getCompositeBillDataPrepare_ac91c0());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList135(){  List list = new ArrayList();  list.add(getBodyAddLineAction_bea9b9());  list.add(getBodyInsertLineAction_178d1e4());  list.add(getBodyDelLineAction_11be2f4());  list.add(getBodyCopyLineAction_1d11120());  list.add(getBodyPasteLineAction_bb7d05());  list.add(getBodyPasteToTailAction_10cdeeb());  list.add(getBodyLineEditAction_1ff4f42());  return list;}

private nc.ui.pubapp.uif2app.actions.BodyAddLineAction getBodyAddLineAction_bea9b9(){
 if(context.get("nc.ui.pubapp.uif2app.actions.BodyAddLineAction#bea9b9")!=null)
 return (nc.ui.pubapp.uif2app.actions.BodyAddLineAction)context.get("nc.ui.pubapp.uif2app.actions.BodyAddLineAction#bea9b9");
  nc.ui.pubapp.uif2app.actions.BodyAddLineAction bean = new nc.ui.pubapp.uif2app.actions.BodyAddLineAction();
  context.put("nc.ui.pubapp.uif2app.actions.BodyAddLineAction#bea9b9",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.actions.BodyInsertLineAction getBodyInsertLineAction_178d1e4(){
 if(context.get("nc.ui.pubapp.uif2app.actions.BodyInsertLineAction#178d1e4")!=null)
 return (nc.ui.pubapp.uif2app.actions.BodyInsertLineAction)context.get("nc.ui.pubapp.uif2app.actions.BodyInsertLineAction#178d1e4");
  nc.ui.pubapp.uif2app.actions.BodyInsertLineAction bean = new nc.ui.pubapp.uif2app.actions.BodyInsertLineAction();
  context.put("nc.ui.pubapp.uif2app.actions.BodyInsertLineAction#178d1e4",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.actions.BodyDelLineAction getBodyDelLineAction_11be2f4(){
 if(context.get("nc.ui.pubapp.uif2app.actions.BodyDelLineAction#11be2f4")!=null)
 return (nc.ui.pubapp.uif2app.actions.BodyDelLineAction)context.get("nc.ui.pubapp.uif2app.actions.BodyDelLineAction#11be2f4");
  nc.ui.pubapp.uif2app.actions.BodyDelLineAction bean = new nc.ui.pubapp.uif2app.actions.BodyDelLineAction();
  context.put("nc.ui.pubapp.uif2app.actions.BodyDelLineAction#11be2f4",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.actions.BodyCopyLineAction getBodyCopyLineAction_1d11120(){
 if(context.get("nc.ui.pubapp.uif2app.actions.BodyCopyLineAction#1d11120")!=null)
 return (nc.ui.pubapp.uif2app.actions.BodyCopyLineAction)context.get("nc.ui.pubapp.uif2app.actions.BodyCopyLineAction#1d11120");
  nc.ui.pubapp.uif2app.actions.BodyCopyLineAction bean = new nc.ui.pubapp.uif2app.actions.BodyCopyLineAction();
  context.put("nc.ui.pubapp.uif2app.actions.BodyCopyLineAction#1d11120",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.actions.BodyPasteLineAction getBodyPasteLineAction_bb7d05(){
 if(context.get("nc.ui.pubapp.uif2app.actions.BodyPasteLineAction#bb7d05")!=null)
 return (nc.ui.pubapp.uif2app.actions.BodyPasteLineAction)context.get("nc.ui.pubapp.uif2app.actions.BodyPasteLineAction#bb7d05");
  nc.ui.pubapp.uif2app.actions.BodyPasteLineAction bean = new nc.ui.pubapp.uif2app.actions.BodyPasteLineAction();
  context.put("nc.ui.pubapp.uif2app.actions.BodyPasteLineAction#bb7d05",bean);
  bean.setClearItems(getManagedList136());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList136(){  List list = new ArrayList();  list.add("pk_repayrcpt_b");  list.add("ts");  return list;}

private nc.ui.pubapp.uif2app.actions.BodyPasteToTailAction getBodyPasteToTailAction_10cdeeb(){
 if(context.get("nc.ui.pubapp.uif2app.actions.BodyPasteToTailAction#10cdeeb")!=null)
 return (nc.ui.pubapp.uif2app.actions.BodyPasteToTailAction)context.get("nc.ui.pubapp.uif2app.actions.BodyPasteToTailAction#10cdeeb");
  nc.ui.pubapp.uif2app.actions.BodyPasteToTailAction bean = new nc.ui.pubapp.uif2app.actions.BodyPasteToTailAction();
  context.put("nc.ui.pubapp.uif2app.actions.BodyPasteToTailAction#10cdeeb",bean);
  bean.setClearItems(getManagedList137());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList137(){  List list = new ArrayList();  list.add("pk_repayrcpt_b");  list.add("ts");  return list;}

private nc.ui.pubapp.uif2app.actions.BodyLineEditAction getBodyLineEditAction_1ff4f42(){
 if(context.get("nc.ui.pubapp.uif2app.actions.BodyLineEditAction#1ff4f42")!=null)
 return (nc.ui.pubapp.uif2app.actions.BodyLineEditAction)context.get("nc.ui.pubapp.uif2app.actions.BodyLineEditAction#1ff4f42");
  nc.ui.pubapp.uif2app.actions.BodyLineEditAction bean = new nc.ui.pubapp.uif2app.actions.BodyLineEditAction();
  context.put("nc.ui.pubapp.uif2app.actions.BodyLineEditAction#1ff4f42",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.view.CompositeBillDataPrepare getCompositeBillDataPrepare_ac91c0(){
 if(context.get("nc.ui.pubapp.uif2app.view.CompositeBillDataPrepare#ac91c0")!=null)
 return (nc.ui.pubapp.uif2app.view.CompositeBillDataPrepare)context.get("nc.ui.pubapp.uif2app.view.CompositeBillDataPrepare#ac91c0");
  nc.ui.pubapp.uif2app.view.CompositeBillDataPrepare bean = new nc.ui.pubapp.uif2app.view.CompositeBillDataPrepare();
  context.put("nc.ui.pubapp.uif2app.view.CompositeBillDataPrepare#ac91c0",bean);
  bean.setBillDataPrepares(getManagedList138());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList138(){  List list = new ArrayList();  list.add(getUserdefitemPreparator());  list.add(getMarAsstPreparator());  return list;}

public nc.ui.uif2.editor.UserdefitemContainerPreparator getUserdefitemPreparator(){
 if(context.get("userdefitemPreparator")!=null)
 return (nc.ui.uif2.editor.UserdefitemContainerPreparator)context.get("userdefitemPreparator");
  nc.ui.uif2.editor.UserdefitemContainerPreparator bean = new nc.ui.uif2.editor.UserdefitemContainerPreparator();
  context.put("userdefitemPreparator",bean);
  bean.setContainer(getUserdefitemContainer());
  bean.setParams(getManagedList139());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList139(){  List list = new ArrayList();  list.add(getUserdefQueryParam_194dac0());  list.add(getUserdefQueryParam_1a57e51());  return list;}

private nc.ui.uif2.editor.UserdefQueryParam getUserdefQueryParam_194dac0(){
 if(context.get("nc.ui.uif2.editor.UserdefQueryParam#194dac0")!=null)
 return (nc.ui.uif2.editor.UserdefQueryParam)context.get("nc.ui.uif2.editor.UserdefQueryParam#194dac0");
  nc.ui.uif2.editor.UserdefQueryParam bean = new nc.ui.uif2.editor.UserdefQueryParam();
  context.put("nc.ui.uif2.editor.UserdefQueryParam#194dac0",bean);
  bean.setMdfullname("cdm.RePayRcptBankCredit");
  bean.setPos(0);
  bean.setPrefix("vdef");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.editor.UserdefQueryParam getUserdefQueryParam_1a57e51(){
 if(context.get("nc.ui.uif2.editor.UserdefQueryParam#1a57e51")!=null)
 return (nc.ui.uif2.editor.UserdefQueryParam)context.get("nc.ui.uif2.editor.UserdefQueryParam#1a57e51");
  nc.ui.uif2.editor.UserdefQueryParam bean = new nc.ui.uif2.editor.UserdefQueryParam();
  context.put("nc.ui.uif2.editor.UserdefQueryParam#1a57e51",bean);
  bean.setMdfullname("cdm.RePayRcptBankCreditSub");
  bean.setPos(1);
  bean.setPrefix("vdef");
  bean.setTabcode("repayrcptsub");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.view.material.assistant.MarAsstPreparator getMarAsstPreparator(){
 if(context.get("marAsstPreparator")!=null)
 return (nc.ui.pubapp.uif2app.view.material.assistant.MarAsstPreparator)context.get("marAsstPreparator");
  nc.ui.pubapp.uif2app.view.material.assistant.MarAsstPreparator bean = new nc.ui.pubapp.uif2app.view.material.assistant.MarAsstPreparator();
  context.put("marAsstPreparator",bean);
  bean.setModel(getManageAppModel());
  bean.setContainer(getUserdefitemContainer());
  bean.setPrefix("vfree");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.userdefitem.UserDefItemContainer getUserdefitemContainer(){
 if(context.get("userdefitemContainer")!=null)
 return (nc.ui.uif2.userdefitem.UserDefItemContainer)context.get("userdefitemContainer");
  nc.ui.uif2.userdefitem.UserDefItemContainer bean = new nc.ui.uif2.userdefitem.UserDefItemContainer();
  context.put("userdefitemContainer",bean);
  bean.setContext(getContext());
  bean.setParams(getManagedList140());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList140(){  List list = new ArrayList();  list.add(getQueryParam_828e5());  list.add(getQueryParam_1b508c5());  list.add(getQueryParam_52dd29());  return list;}

private nc.ui.uif2.userdefitem.QueryParam getQueryParam_828e5(){
 if(context.get("nc.ui.uif2.userdefitem.QueryParam#828e5")!=null)
 return (nc.ui.uif2.userdefitem.QueryParam)context.get("nc.ui.uif2.userdefitem.QueryParam#828e5");
  nc.ui.uif2.userdefitem.QueryParam bean = new nc.ui.uif2.userdefitem.QueryParam();
  context.put("nc.ui.uif2.userdefitem.QueryParam#828e5",bean);
  bean.setMdfullname("cdm.RePayRcptBankCredit");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.userdefitem.QueryParam getQueryParam_1b508c5(){
 if(context.get("nc.ui.uif2.userdefitem.QueryParam#1b508c5")!=null)
 return (nc.ui.uif2.userdefitem.QueryParam)context.get("nc.ui.uif2.userdefitem.QueryParam#1b508c5");
  nc.ui.uif2.userdefitem.QueryParam bean = new nc.ui.uif2.userdefitem.QueryParam();
  context.put("nc.ui.uif2.userdefitem.QueryParam#1b508c5",bean);
  bean.setMdfullname("cdm.RePayRcptBankCreditSub");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.userdefitem.QueryParam getQueryParam_52dd29(){
 if(context.get("nc.ui.uif2.userdefitem.QueryParam#52dd29")!=null)
 return (nc.ui.uif2.userdefitem.QueryParam)context.get("nc.ui.uif2.userdefitem.QueryParam#52dd29");
  nc.ui.uif2.userdefitem.QueryParam bean = new nc.ui.uif2.userdefitem.QueryParam();
  context.put("nc.ui.uif2.userdefitem.QueryParam#52dd29",bean);
  bean.setRulecode("materialassistant");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.tangramlayout.UEQueryAreaShell getQueryArea(){
 if(context.get("queryArea")!=null)
 return (nc.ui.pubapp.uif2app.tangramlayout.UEQueryAreaShell)context.get("queryArea");
  nc.ui.pubapp.uif2app.tangramlayout.UEQueryAreaShell bean = new nc.ui.pubapp.uif2app.tangramlayout.UEQueryAreaShell();
  context.put("queryArea",bean);
  bean.setQueryAreaCreator(getQueryAction());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.tangramlayout.CardLayoutToolbarPanel getQueryInfo(){
 if(context.get("queryInfo")!=null)
 return (nc.ui.uif2.tangramlayout.CardLayoutToolbarPanel)context.get("queryInfo");
  nc.ui.uif2.tangramlayout.CardLayoutToolbarPanel bean = new nc.ui.uif2.tangramlayout.CardLayoutToolbarPanel();
  context.put("queryInfo",bean);
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.tangramlayout.UECardLayoutToolbarPanel getCardInfoPnl(){
 if(context.get("cardInfoPnl")!=null)
 return (nc.ui.pubapp.uif2app.tangramlayout.UECardLayoutToolbarPanel)context.get("cardInfoPnl");
  nc.ui.pubapp.uif2app.tangramlayout.UECardLayoutToolbarPanel bean = new nc.ui.pubapp.uif2app.tangramlayout.UECardLayoutToolbarPanel();
  context.put("cardInfoPnl",bean);
  bean.setTitleAction(getReturnaction());
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.actions.UEReturnAction getReturnaction(){
 if(context.get("returnaction")!=null)
 return (nc.ui.pubapp.uif2app.actions.UEReturnAction)context.get("returnaction");
  nc.ui.pubapp.uif2app.actions.UEReturnAction bean = new nc.ui.pubapp.uif2app.actions.UEReturnAction();
  context.put("returnaction",bean);
  bean.setGoComponent(getListView());
  bean.setSaveAction(getSaveAction());
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.TangramContainer getContainer(){
 if(context.get("container")!=null)
 return (nc.ui.uif2.TangramContainer)context.get("container");
  nc.ui.uif2.TangramContainer bean = new nc.ui.uif2.TangramContainer();
  context.put("container",bean);
  bean.setModel(getManageAppModel());
  bean.setTangramLayoutRoot(getTBNode_a35265());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.TBNode getTBNode_a35265(){
 if(context.get("nc.ui.uif2.tangramlayout.node.TBNode#a35265")!=null)
 return (nc.ui.uif2.tangramlayout.node.TBNode)context.get("nc.ui.uif2.tangramlayout.node.TBNode#a35265");
  nc.ui.uif2.tangramlayout.node.TBNode bean = new nc.ui.uif2.tangramlayout.node.TBNode();
  context.put("nc.ui.uif2.tangramlayout.node.TBNode#a35265",bean);
  bean.setShowMode("CardLayout");
  bean.setTabs(getManagedList141());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList141(){  List list = new ArrayList();  list.add(getHSNode_5cd690());  list.add(getVSNode_4a5f01());  return list;}

private nc.ui.uif2.tangramlayout.node.HSNode getHSNode_5cd690(){
 if(context.get("nc.ui.uif2.tangramlayout.node.HSNode#5cd690")!=null)
 return (nc.ui.uif2.tangramlayout.node.HSNode)context.get("nc.ui.uif2.tangramlayout.node.HSNode#5cd690");
  nc.ui.uif2.tangramlayout.node.HSNode bean = new nc.ui.uif2.tangramlayout.node.HSNode();
  context.put("nc.ui.uif2.tangramlayout.node.HSNode#5cd690",bean);
  bean.setLeft(getCNode_35cba2());
  bean.setRight(getVSNode_10783c8());
  bean.setDividerLocation(210f);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.CNode getCNode_35cba2(){
 if(context.get("nc.ui.uif2.tangramlayout.node.CNode#35cba2")!=null)
 return (nc.ui.uif2.tangramlayout.node.CNode)context.get("nc.ui.uif2.tangramlayout.node.CNode#35cba2");
  nc.ui.uif2.tangramlayout.node.CNode bean = new nc.ui.uif2.tangramlayout.node.CNode();
  context.put("nc.ui.uif2.tangramlayout.node.CNode#35cba2",bean);
  bean.setComponent(getQueryArea());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.VSNode getVSNode_10783c8(){
 if(context.get("nc.ui.uif2.tangramlayout.node.VSNode#10783c8")!=null)
 return (nc.ui.uif2.tangramlayout.node.VSNode)context.get("nc.ui.uif2.tangramlayout.node.VSNode#10783c8");
  nc.ui.uif2.tangramlayout.node.VSNode bean = new nc.ui.uif2.tangramlayout.node.VSNode();
  context.put("nc.ui.uif2.tangramlayout.node.VSNode#10783c8",bean);
  bean.setUp(getCNode_1cc1db7());
  bean.setDown(getCNode_1c86b77());
  bean.setDividerLocation(25f);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.CNode getCNode_1cc1db7(){
 if(context.get("nc.ui.uif2.tangramlayout.node.CNode#1cc1db7")!=null)
 return (nc.ui.uif2.tangramlayout.node.CNode)context.get("nc.ui.uif2.tangramlayout.node.CNode#1cc1db7");
  nc.ui.uif2.tangramlayout.node.CNode bean = new nc.ui.uif2.tangramlayout.node.CNode();
  context.put("nc.ui.uif2.tangramlayout.node.CNode#1cc1db7",bean);
  bean.setComponent(getQueryInfo());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.CNode getCNode_1c86b77(){
 if(context.get("nc.ui.uif2.tangramlayout.node.CNode#1c86b77")!=null)
 return (nc.ui.uif2.tangramlayout.node.CNode)context.get("nc.ui.uif2.tangramlayout.node.CNode#1c86b77");
  nc.ui.uif2.tangramlayout.node.CNode bean = new nc.ui.uif2.tangramlayout.node.CNode();
  context.put("nc.ui.uif2.tangramlayout.node.CNode#1c86b77",bean);
  bean.setName(getI18nFB_1b2fc27());
  bean.setComponent(getListView());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private java.lang.String getI18nFB_1b2fc27(){
 if(context.get("nc.ui.uif2.I18nFB#1b2fc27")!=null)
 return (java.lang.String)context.get("nc.ui.uif2.I18nFB#1b2fc27");
  nc.ui.uif2.I18nFB bean = new nc.ui.uif2.I18nFB();
    context.put("&nc.ui.uif2.I18nFB#1b2fc27",bean);  bean.setResDir("common");
  bean.setResId("UC001-0000107");
  bean.setDefaultValue("�б�");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
 try {
     Object product = bean.getObject();
    context.put("nc.ui.uif2.I18nFB#1b2fc27",product);
     return (java.lang.String)product;
}
catch(Exception e) { throw new RuntimeException(e);}}

private nc.ui.uif2.tangramlayout.node.VSNode getVSNode_4a5f01(){
 if(context.get("nc.ui.uif2.tangramlayout.node.VSNode#4a5f01")!=null)
 return (nc.ui.uif2.tangramlayout.node.VSNode)context.get("nc.ui.uif2.tangramlayout.node.VSNode#4a5f01");
  nc.ui.uif2.tangramlayout.node.VSNode bean = new nc.ui.uif2.tangramlayout.node.VSNode();
  context.put("nc.ui.uif2.tangramlayout.node.VSNode#4a5f01",bean);
  bean.setUp(getCNode_10aad0d());
  bean.setDown(getCNode_78176e());
  bean.setDividerLocation(30f);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.CNode getCNode_10aad0d(){
 if(context.get("nc.ui.uif2.tangramlayout.node.CNode#10aad0d")!=null)
 return (nc.ui.uif2.tangramlayout.node.CNode)context.get("nc.ui.uif2.tangramlayout.node.CNode#10aad0d");
  nc.ui.uif2.tangramlayout.node.CNode bean = new nc.ui.uif2.tangramlayout.node.CNode();
  context.put("nc.ui.uif2.tangramlayout.node.CNode#10aad0d",bean);
  bean.setComponent(getCardInfoPnl());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.CNode getCNode_78176e(){
 if(context.get("nc.ui.uif2.tangramlayout.node.CNode#78176e")!=null)
 return (nc.ui.uif2.tangramlayout.node.CNode)context.get("nc.ui.uif2.tangramlayout.node.CNode#78176e");
  nc.ui.uif2.tangramlayout.node.CNode bean = new nc.ui.uif2.tangramlayout.node.CNode();
  context.put("nc.ui.uif2.tangramlayout.node.CNode#78176e",bean);
  bean.setName(getI18nFB_1e754eb());
  bean.setComponent(getBillFormEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private java.lang.String getI18nFB_1e754eb(){
 if(context.get("nc.ui.uif2.I18nFB#1e754eb")!=null)
 return (java.lang.String)context.get("nc.ui.uif2.I18nFB#1e754eb");
  nc.ui.uif2.I18nFB bean = new nc.ui.uif2.I18nFB();
    context.put("&nc.ui.uif2.I18nFB#1e754eb",bean);  bean.setResDir("common");
  bean.setResId("UC001-0000106");
  bean.setDefaultValue("��Ƭ");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
 try {
     Object product = bean.getObject();
    context.put("nc.ui.uif2.I18nFB#1e754eb",product);
     return (java.lang.String)product;
}
catch(Exception e) { throw new RuntimeException(e);}}

public nc.ui.pubapp.uif2app.event.ChildrenPicky getChildrenPicky(){
 if(context.get("childrenPicky")!=null)
 return (nc.ui.pubapp.uif2app.event.ChildrenPicky)context.get("childrenPicky");
  nc.ui.pubapp.uif2app.event.ChildrenPicky bean = new nc.ui.pubapp.uif2app.event.ChildrenPicky();
  context.put("childrenPicky",bean);
  bean.setBillform(getBillFormEditor());
  bean.setBodyVoClasses(getManagedList142());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList142(){  List list = new ArrayList();  list.add("nc.vo.cdm.repayreceiptbankcredit.RePayReceiptBankCreditBVO");  list.add("nc.vo.cdm.repayreceiptbankcredit.RePayRcptBankInfo");  return list;}

public nc.ui.pubapp.uif2app.model.AppEventHandlerMediator getEventMediator(){
 if(context.get("eventMediator")!=null)
 return (nc.ui.pubapp.uif2app.model.AppEventHandlerMediator)context.get("eventMediator");
  nc.ui.pubapp.uif2app.model.AppEventHandlerMediator bean = new nc.ui.pubapp.uif2app.model.AppEventHandlerMediator();
  context.put("eventMediator",bean);
  bean.setModel(getManageAppModel());
  bean.setHandlerGroup(getManagedList143());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList143(){  List list = new ArrayList();  list.add(getEventHandlerGroup_19067f0());  list.add(getEventHandlerGroup_18872d0());  list.add(getEventHandlerGroup_a535dc());  list.add(getEventHandlerGroup_4cf65f());  list.add(getEventHandlerGroup_167a4ee());  list.add(getEventHandlerGroup_12e45f7());  list.add(getEventHandlerGroup_fdcbfe());  return list;}

private nc.ui.pubapp.uif2app.event.EventHandlerGroup getEventHandlerGroup_19067f0(){
 if(context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#19067f0")!=null)
 return (nc.ui.pubapp.uif2app.event.EventHandlerGroup)context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#19067f0");
  nc.ui.pubapp.uif2app.event.EventHandlerGroup bean = new nc.ui.pubapp.uif2app.event.EventHandlerGroup();
  context.put("nc.ui.pubapp.uif2app.event.EventHandlerGroup#19067f0",bean);
  bean.setEvent("nc.ui.pubapp.uif2app.event.card.CardBodyBeforeEditEvent");
  bean.setPicky(getChildrenPicky());
  bean.setHandler(getAceBodyBeforeEditHandler_766f78());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyBeforeEditHandler getAceBodyBeforeEditHandler_766f78(){
 if(context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyBeforeEditHandler#766f78")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyBeforeEditHandler)context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyBeforeEditHandler#766f78");
  nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyBeforeEditHandler bean = new nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyBeforeEditHandler();
  context.put("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyBeforeEditHandler#766f78",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.event.EventHandlerGroup getEventHandlerGroup_18872d0(){
 if(context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#18872d0")!=null)
 return (nc.ui.pubapp.uif2app.event.EventHandlerGroup)context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#18872d0");
  nc.ui.pubapp.uif2app.event.EventHandlerGroup bean = new nc.ui.pubapp.uif2app.event.EventHandlerGroup();
  context.put("nc.ui.pubapp.uif2app.event.EventHandlerGroup#18872d0",bean);
  bean.setEvent("nc.ui.pubapp.uif2app.event.card.CardBodyAfterEditEvent");
  bean.setPicky(getChildrenPicky());
  bean.setHandler(getAceBodyAfterEditHandler_197cec7());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyAfterEditHandler getAceBodyAfterEditHandler_197cec7(){
 if(context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyAfterEditHandler#197cec7")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyAfterEditHandler)context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyAfterEditHandler#197cec7");
  nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyAfterEditHandler bean = new nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyAfterEditHandler(getBillFormEditor());  context.put("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceBodyAfterEditHandler#197cec7",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.event.EventHandlerGroup getEventHandlerGroup_a535dc(){
 if(context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#a535dc")!=null)
 return (nc.ui.pubapp.uif2app.event.EventHandlerGroup)context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#a535dc");
  nc.ui.pubapp.uif2app.event.EventHandlerGroup bean = new nc.ui.pubapp.uif2app.event.EventHandlerGroup();
  context.put("nc.ui.pubapp.uif2app.event.EventHandlerGroup#a535dc",bean);
  bean.setEvent("nc.ui.pubapp.uif2app.event.card.CardHeadTailBeforeEditEvent");
  bean.setHandler(getAceHeadTailBeforeEditHandler_129d22b());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailBeforeEditHandler getAceHeadTailBeforeEditHandler_129d22b(){
 if(context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailBeforeEditHandler#129d22b")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailBeforeEditHandler)context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailBeforeEditHandler#129d22b");
  nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailBeforeEditHandler bean = new nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailBeforeEditHandler();
  context.put("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailBeforeEditHandler#129d22b",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.event.EventHandlerGroup getEventHandlerGroup_4cf65f(){
 if(context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#4cf65f")!=null)
 return (nc.ui.pubapp.uif2app.event.EventHandlerGroup)context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#4cf65f");
  nc.ui.pubapp.uif2app.event.EventHandlerGroup bean = new nc.ui.pubapp.uif2app.event.EventHandlerGroup();
  context.put("nc.ui.pubapp.uif2app.event.EventHandlerGroup#4cf65f",bean);
  bean.setEvent("nc.ui.pubapp.uif2app.event.card.CardHeadTailAfterEditEvent");
  bean.setHandler(getAceHeadTailAfterEditHandler_73187d());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailAfterEditHandler getAceHeadTailAfterEditHandler_73187d(){
 if(context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailAfterEditHandler#73187d")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailAfterEditHandler)context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailAfterEditHandler#73187d");
  nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailAfterEditHandler bean = new nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailAfterEditHandler(getBillFormEditor());  context.put("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceHeadTailAfterEditHandler#73187d",bean);
  bean.setDigitListener(getDigitListener());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.event.EventHandlerGroup getEventHandlerGroup_167a4ee(){
 if(context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#167a4ee")!=null)
 return (nc.ui.pubapp.uif2app.event.EventHandlerGroup)context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#167a4ee");
  nc.ui.pubapp.uif2app.event.EventHandlerGroup bean = new nc.ui.pubapp.uif2app.event.EventHandlerGroup();
  context.put("nc.ui.pubapp.uif2app.event.EventHandlerGroup#167a4ee",bean);
  bean.setEvent("nc.ui.pubapp.uif2app.event.billform.AddEvent");
  bean.setHandler(getAceAddHandler_c30c78());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceAddHandler getAceAddHandler_c30c78(){
 if(context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceAddHandler#c30c78")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceAddHandler)context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceAddHandler#c30c78");
  nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceAddHandler bean = new nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceAddHandler();
  context.put("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceAddHandler#c30c78",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.event.EventHandlerGroup getEventHandlerGroup_12e45f7(){
 if(context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#12e45f7")!=null)
 return (nc.ui.pubapp.uif2app.event.EventHandlerGroup)context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#12e45f7");
  nc.ui.pubapp.uif2app.event.EventHandlerGroup bean = new nc.ui.pubapp.uif2app.event.EventHandlerGroup();
  context.put("nc.ui.pubapp.uif2app.event.EventHandlerGroup#12e45f7",bean);
  bean.setEvent("nc.ui.pubapp.uif2app.event.OrgChangedEvent");
  bean.setHandler(getAceOrgChangedHandler_17d0e2f());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceOrgChangedHandler getAceOrgChangedHandler_17d0e2f(){
 if(context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceOrgChangedHandler#17d0e2f")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceOrgChangedHandler)context.get("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceOrgChangedHandler#17d0e2f");
  nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceOrgChangedHandler bean = new nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceOrgChangedHandler(getBillFormEditor());  context.put("nc.ui.cdm.repayreceiptbankcredit.ace.handler.AceOrgChangedHandler#17d0e2f",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.event.EventHandlerGroup getEventHandlerGroup_fdcbfe(){
 if(context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#fdcbfe")!=null)
 return (nc.ui.pubapp.uif2app.event.EventHandlerGroup)context.get("nc.ui.pubapp.uif2app.event.EventHandlerGroup#fdcbfe");
  nc.ui.pubapp.uif2app.event.EventHandlerGroup bean = new nc.ui.pubapp.uif2app.event.EventHandlerGroup();
  context.put("nc.ui.pubapp.uif2app.event.EventHandlerGroup#fdcbfe",bean);
  bean.setEvent("nc.ui.pubapp.uif2app.event.card.CardBodyAfterRowEditEvent");
  bean.setHandler(getBankCardBodyAfterRowEditHandler_f36b1f());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pub.repay.handler.BankCardBodyAfterRowEditHandler getBankCardBodyAfterRowEditHandler_f36b1f(){
 if(context.get("nc.ui.pub.repay.handler.BankCardBodyAfterRowEditHandler#f36b1f")!=null)
 return (nc.ui.pub.repay.handler.BankCardBodyAfterRowEditHandler)context.get("nc.ui.pub.repay.handler.BankCardBodyAfterRowEditHandler#f36b1f");
  nc.ui.pub.repay.handler.BankCardBodyAfterRowEditHandler bean = new nc.ui.pub.repay.handler.BankCardBodyAfterRowEditHandler(getBillFormEditor());  context.put("nc.ui.pub.repay.handler.BankCardBodyAfterRowEditHandler#f36b1f",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.actions.ActionContributors getToftpanelActionContributors(){
 if(context.get("toftpanelActionContributors")!=null)
 return (nc.ui.uif2.actions.ActionContributors)context.get("toftpanelActionContributors");
  nc.ui.uif2.actions.ActionContributors bean = new nc.ui.uif2.actions.ActionContributors();
  context.put("toftpanelActionContributors",bean);
  bean.setContributors(getManagedList144());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList144(){  List list = new ArrayList();  list.add(getActionsOfList());  list.add(getActionsOfCard());  return list;}

public nc.ui.uif2.actions.StandAloneToftPanelActionContainer getActionsOfList(){
 if(context.get("actionsOfList")!=null)
 return (nc.ui.uif2.actions.StandAloneToftPanelActionContainer)context.get("actionsOfList");
  nc.ui.uif2.actions.StandAloneToftPanelActionContainer bean = new nc.ui.uif2.actions.StandAloneToftPanelActionContainer(getListView());  context.put("actionsOfList",bean);
  bean.setModel(getManageAppModel());
  bean.setActions(getManagedList145());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList145(){  List list = new ArrayList();  list.add(getAddAction());  list.add(getEditAction());  list.add(getDeleteAction());  list.add(getCopyAction());  list.add(getSeparatorAction());  list.add(getQueryAction());  list.add(getRefreshAction());  list.add(getSeparatorAction());  list.add(getCommitMenuAction());  list.add(getAuditMenuAction());  list.add(getSupportMenuAction());  list.add(getSeparatorAction());  list.add(getLinkMenuAction());  list.add(getSeparatorAction());  list.add(getList_printMenuAction());  list.add(getSeparatorAction());  return list;}

public nc.ui.uif2.actions.StandAloneToftPanelActionContainer getActionsOfCard(){
 if(context.get("actionsOfCard")!=null)
 return (nc.ui.uif2.actions.StandAloneToftPanelActionContainer)context.get("actionsOfCard");
  nc.ui.uif2.actions.StandAloneToftPanelActionContainer bean = new nc.ui.uif2.actions.StandAloneToftPanelActionContainer(getBillFormEditor());  context.put("actionsOfCard",bean);
  bean.setModel(getManageAppModel());
  bean.setActions(getManagedList146());
  bean.setEditActions(getManagedList147());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList146(){  List list = new ArrayList();  list.add(getAddAction());  list.add(getEditAction());  list.add(getDeleteAction());  list.add(getCopyAction());  list.add(getSeparatorAction());  list.add(getQueryAction());  list.add(getCardRefreshAction());  list.add(getSeparatorAction());  list.add(getCommitMenuAction());  list.add(getAuditMenuAction());  list.add(getSupportMenuAction());  list.add(getSeparatorAction());  list.add(getLinkMenuAction());  list.add(getSeparatorAction());  list.add(getCard_printMenuAction());  list.add(getSeparatorAction());  return list;}

private List getManagedList147(){  List list = new ArrayList();  list.add(getSaveAction());  list.add(getSaveAddAction());  list.add(getSaveSendApproveAction());  list.add(getSeparatorAction());  list.add(getCancelAction());  return list;}

public nc.ui.pub.Action.AssistantMenuAction getSupportMenuAction(){
 if(context.get("supportMenuAction")!=null)
 return (nc.ui.pub.Action.AssistantMenuAction)context.get("supportMenuAction");
  nc.ui.pub.Action.AssistantMenuAction bean = new nc.ui.pub.Action.AssistantMenuAction();
  context.put("supportMenuAction",bean);
  bean.setActions(getManagedList148());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList148(){  List list = new ArrayList();  list.add(getAttachmentAction());  return list;}

private nc.ui.tm.base.actions.TMBaseFileDocManageAction getAttachmentAction(){
 if(context.get("attachmentAction")!=null)
 return (nc.ui.tm.base.actions.TMBaseFileDocManageAction)context.get("attachmentAction");
  nc.ui.tm.base.actions.TMBaseFileDocManageAction bean = new nc.ui.tm.base.actions.TMBaseFileDocManageAction();
  context.put("attachmentAction",bean);
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.funcnode.ui.action.SeparatorAction getSeparatorAction(){
 if(context.get("separatorAction")!=null)
 return (nc.funcnode.ui.action.SeparatorAction)context.get("separatorAction");
  nc.funcnode.ui.action.SeparatorAction bean = new nc.funcnode.ui.action.SeparatorAction();
  context.put("separatorAction",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.interceptor.ShowUpComponentInterceptor getShowListInterceptor(){
 if(context.get("showListInterceptor")!=null)
 return (nc.ui.pubapp.uif2app.actions.interceptor.ShowUpComponentInterceptor)context.get("showListInterceptor");
  nc.ui.pubapp.uif2app.actions.interceptor.ShowUpComponentInterceptor bean = new nc.ui.pubapp.uif2app.actions.interceptor.ShowUpComponentInterceptor();
  context.put("showListInterceptor",bean);
  bean.setShowUpComponent(getListView());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.interceptor.ShowUpComponentInterceptor getShowCardInterceptor(){
 if(context.get("showCardInterceptor")!=null)
 return (nc.ui.pubapp.uif2app.actions.interceptor.ShowUpComponentInterceptor)context.get("showCardInterceptor");
  nc.ui.pubapp.uif2app.actions.interceptor.ShowUpComponentInterceptor bean = new nc.ui.pubapp.uif2app.actions.interceptor.ShowUpComponentInterceptor();
  context.put("showCardInterceptor",bean);
  bean.setShowUpComponent(getBillFormEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.AddAction getAddAction(){
 if(context.get("addAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.AddAction)context.get("addAction");
  nc.ui.pubapp.uif2app.actions.AddAction bean = new nc.ui.pubapp.uif2app.actions.AddAction();
  context.put("addAction",bean);
  bean.setModel(getManageAppModel());
  bean.setInterceptor(getShowCardInterceptor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.repay.action.RePayEditAction getEditAction(){
 if(context.get("editAction")!=null)
 return (nc.ui.pub.repay.action.RePayEditAction)context.get("editAction");
  nc.ui.pub.repay.action.RePayEditAction bean = new nc.ui.pub.repay.action.RePayEditAction();
  context.put("editAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setPowercheck(true);
  bean.setBillType("36FF");
  bean.setBillCodeName("vbillno");
  bean.setInterceptor(getShowCardInterceptor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditDeleteAction getDeleteAction(){
 if(context.get("deleteAction")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditDeleteAction)context.get("deleteAction");
  nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditDeleteAction bean = new nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditDeleteAction();
  context.put("deleteAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setActionName("DELETE");
  bean.setPowercheck(true);
  bean.setBillType("36FF");
  bean.setBillCodeName("vbillno");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.Action.SaveScriptAction getSaveAction(){
 if(context.get("saveAction")!=null)
 return (nc.ui.pub.Action.SaveScriptAction)context.get("saveAction");
  nc.ui.pub.Action.SaveScriptAction bean = new nc.ui.pub.Action.SaveScriptAction();
  context.put("saveAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setActionName("SAVEBASE");
  bean.setBillType("36FF");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.Action.CDMSaveAddAction getSaveAddAction(){
 if(context.get("saveAddAction")!=null)
 return (nc.ui.pub.Action.CDMSaveAddAction)context.get("saveAddAction");
  nc.ui.pub.Action.CDMSaveAddAction bean = new nc.ui.pub.Action.CDMSaveAddAction();
  context.put("saveAddAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setAddAction(getAddAction());
  bean.setSaveAction(getSaveAction());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.pflow.SaveAndCommitScriptAction getSaveSendApproveAction(){
 if(context.get("saveSendApproveAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.pflow.SaveAndCommitScriptAction)context.get("saveSendApproveAction");
  nc.ui.pubapp.uif2app.actions.pflow.SaveAndCommitScriptAction bean = new nc.ui.pubapp.uif2app.actions.pflow.SaveAndCommitScriptAction(getSaveAction(),getCommitAction());  context.put("saveSendApproveAction",bean);
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.validation.CompositeValidation getValidateService(){
 if(context.get("validateService")!=null)
 return (nc.ui.pubapp.uif2app.validation.CompositeValidation)context.get("validateService");
  nc.ui.pubapp.uif2app.validation.CompositeValidation bean = new nc.ui.pubapp.uif2app.validation.CompositeValidation();
  context.put("validateService",bean);
  bean.setValidators(getManagedList149());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList149(){  List list = new ArrayList();  list.add(getTemplateNotNullValidation_5bb51b());  return list;}

private nc.ui.pubapp.uif2app.validation.TemplateNotNullValidation getTemplateNotNullValidation_5bb51b(){
 if(context.get("nc.ui.pubapp.uif2app.validation.TemplateNotNullValidation#5bb51b")!=null)
 return (nc.ui.pubapp.uif2app.validation.TemplateNotNullValidation)context.get("nc.ui.pubapp.uif2app.validation.TemplateNotNullValidation#5bb51b");
  nc.ui.pubapp.uif2app.validation.TemplateNotNullValidation bean = new nc.ui.pubapp.uif2app.validation.TemplateNotNullValidation();
  context.put("nc.ui.pubapp.uif2app.validation.TemplateNotNullValidation#5bb51b",bean);
  bean.setBillForm(getBillFormEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.CancelAction getCancelAction(){
 if(context.get("cancelAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.CancelAction)context.get("cancelAction");
  nc.ui.pubapp.uif2app.actions.CancelAction bean = new nc.ui.pubapp.uif2app.actions.CancelAction();
  context.put("cancelAction",bean);
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.repay.action.RePayCopyAction getCopyAction(){
 if(context.get("copyAction")!=null)
 return (nc.ui.pub.repay.action.RePayCopyAction)context.get("copyAction");
  nc.ui.pub.repay.action.RePayCopyAction bean = new nc.ui.pub.repay.action.RePayCopyAction();
  context.put("copyAction",bean);
  bean.setModel(getManageAppModel());
  bean.setInterceptor(getShowCardInterceptor());
  bean.setEditor(getBillFormEditor());
  bean.setCopyActionProcessor(getCopyActionProcessor_cf209f());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.cdm.repayreceiptbankcredit.action.CopyActionProcessor getCopyActionProcessor_cf209f(){
 if(context.get("nc.ui.cdm.repayreceiptbankcredit.action.CopyActionProcessor#cf209f")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.action.CopyActionProcessor)context.get("nc.ui.cdm.repayreceiptbankcredit.action.CopyActionProcessor#cf209f");
  nc.ui.cdm.repayreceiptbankcredit.action.CopyActionProcessor bean = new nc.ui.cdm.repayreceiptbankcredit.action.CopyActionProcessor();
  context.put("nc.ui.cdm.repayreceiptbankcredit.action.CopyActionProcessor#cf209f",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.cdm.repayreceiptbankcredit.query.RePayReceiptBankCreditQueryConditionInitializer getQryCondInitializer(){
 if(context.get("qryCondInitializer")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.query.RePayReceiptBankCreditQueryConditionInitializer)context.get("qryCondInitializer");
  nc.ui.cdm.repayreceiptbankcredit.query.RePayReceiptBankCreditQueryConditionInitializer bean = new nc.ui.cdm.repayreceiptbankcredit.query.RePayReceiptBankCreditQueryConditionInitializer();
  context.put("qryCondInitializer",bean);
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.query2.action.DefaultQueryAction getQueryAction(){
 if(context.get("queryAction")!=null)
 return (nc.ui.pubapp.uif2app.query2.action.DefaultQueryAction)context.get("queryAction");
  nc.ui.pubapp.uif2app.query2.action.DefaultQueryAction bean = new nc.ui.pubapp.uif2app.query2.action.DefaultQueryAction();
  context.put("queryAction",bean);
  bean.setModel(getManageAppModel());
  bean.setDataManager(getModelDataManager());
  bean.setQryCondDLGInitializer(getQryCondInitializer());
  bean.setShowUpComponent(getListView());
  bean.setTemplateContainer(getQueryTemplateContainer());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.query2.action.DefaultRefreshAction getRefreshAction(){
 if(context.get("refreshAction")!=null)
 return (nc.ui.pubapp.uif2app.query2.action.DefaultRefreshAction)context.get("refreshAction");
  nc.ui.pubapp.uif2app.query2.action.DefaultRefreshAction bean = new nc.ui.pubapp.uif2app.query2.action.DefaultRefreshAction();
  context.put("refreshAction",bean);
  bean.setDataManager(getModelDataManager());
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.RefreshSingleAction getCardRefreshAction(){
 if(context.get("cardRefreshAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.RefreshSingleAction)context.get("cardRefreshAction");
  nc.ui.pubapp.uif2app.actions.RefreshSingleAction bean = new nc.ui.pubapp.uif2app.actions.RefreshSingleAction();
  context.put("cardRefreshAction",bean);
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.pflow.CommitScriptAction getCommitAction(){
 if(context.get("commitAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.pflow.CommitScriptAction)context.get("commitAction");
  nc.ui.pubapp.uif2app.actions.pflow.CommitScriptAction bean = new nc.ui.pubapp.uif2app.actions.pflow.CommitScriptAction();
  context.put("commitAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setBillType("36FF");
  bean.setActionName("SAVE");
  bean.setFilledUpInFlow(true);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.tmpub.action.TMUnCommitAction getUnCommitAction(){
 if(context.get("unCommitAction")!=null)
 return (nc.ui.tmpub.action.TMUnCommitAction)context.get("unCommitAction");
  nc.ui.tmpub.action.TMUnCommitAction bean = new nc.ui.tmpub.action.TMUnCommitAction();
  context.put("unCommitAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setBillType("36FF");
  bean.setActionName("UNSAVEBILL");
  bean.setFilledUpInFlow(true);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.funcnode.ui.action.GroupAction getCommitMenuAction(){
 if(context.get("commitMenuAction")!=null)
 return (nc.funcnode.ui.action.GroupAction)context.get("commitMenuAction");
  nc.funcnode.ui.action.GroupAction bean = new nc.funcnode.ui.action.GroupAction();
  context.put("commitMenuAction",bean);
  bean.setCode("commitMenuAction");
  bean.setActions(getManagedList150());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList150(){  List list = new ArrayList();  list.add(getCommitAction());  list.add(getUnCommitAction());  return list;}

public nc.ui.pubapp.pub.power.PowerValidateService getApprovepowervalidservice(){
 if(context.get("approvepowervalidservice")!=null)
 return (nc.ui.pubapp.pub.power.PowerValidateService)context.get("approvepowervalidservice");
  nc.ui.pubapp.pub.power.PowerValidateService bean = new nc.ui.pubapp.pub.power.PowerValidateService();
  context.put("approvepowervalidservice",bean);
  bean.setActionCode("approve");
  bean.setBillCodeFiledName("vbillno");
  bean.setPermissionCode("36FF");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.pub.power.PowerValidateService getUnapprovepowervalidservice(){
 if(context.get("unapprovepowervalidservice")!=null)
 return (nc.ui.pubapp.pub.power.PowerValidateService)context.get("unapprovepowervalidservice");
  nc.ui.pubapp.pub.power.PowerValidateService bean = new nc.ui.pubapp.pub.power.PowerValidateService();
  context.put("unapprovepowervalidservice",bean);
  bean.setActionCode("unapprove");
  bean.setBillCodeFiledName("vbillno");
  bean.setPermissionCode("36FF");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditApproveAction getApproveAction(){
 if(context.get("approveAction")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditApproveAction)context.get("approveAction");
  nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditApproveAction bean = new nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditApproveAction();
  context.put("approveAction",bean);
  bean.setModel(getManageAppModel());
  bean.setDataManager(getModelDataManager());
  bean.setEditor(getBillFormEditor());
  bean.setBillType("36FF");
  bean.setActionName("APPROVE");
  bean.setValidationService(getApprovepowervalidservice());
  bean.setFilledUpInFlow(true);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditUnApproveAction getUnApproveAction(){
 if(context.get("unApproveAction")!=null)
 return (nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditUnApproveAction)context.get("unApproveAction");
  nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditUnApproveAction bean = new nc.ui.cdm.repayreceiptbankcredit.action.RePayReceiptBankCreditUnApproveAction();
  context.put("unApproveAction",bean);
  bean.setModel(getManageAppModel());
  bean.setEditor(getBillFormEditor());
  bean.setBillType("36FF");
  bean.setActionName("UNAPPROVE");
  bean.setValidationService(getUnapprovepowervalidservice());
  bean.setFilledUpInFlow(true);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.funcnode.ui.action.GroupAction getAuditMenuAction(){
 if(context.get("auditMenuAction")!=null)
 return (nc.funcnode.ui.action.GroupAction)context.get("auditMenuAction");
  nc.funcnode.ui.action.GroupAction bean = new nc.funcnode.ui.action.GroupAction();
  context.put("auditMenuAction",bean);
  bean.setCode("auditMenuAction");
  bean.setActions(getManagedList151());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList151(){  List list = new ArrayList();  list.add(getApproveAction());  list.add(getUnApproveAction());  list.add(getQueryAuditFlowAction());  return list;}

public nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction getPrintAction(){
 if(context.get("printAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction)context.get("printAction");
  nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction bean = new nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction();
  context.put("printAction",bean);
  bean.setPreview(false);
  bean.setModel(getManageAppModel());
  bean.setBeforePrintDataProcess(getPrintProcessor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction getPreviewAction(){
 if(context.get("previewAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction)context.get("previewAction");
  nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction bean = new nc.ui.pubapp.uif2app.actions.MetaDataBasedPrintAction();
  context.put("previewAction",bean);
  bean.setPreview(true);
  bean.setModel(getManageAppModel());
  bean.setBeforePrintDataProcess(getPrintProcessor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.actions.OutputAction getOutputAction(){
 if(context.get("outputAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.OutputAction)context.get("outputAction");
  nc.ui.pubapp.uif2app.actions.OutputAction bean = new nc.ui.pubapp.uif2app.actions.OutputAction();
  context.put("outputAction",bean);
  bean.setModel(getManageAppModel());
  bean.setParent(getBillFormEditor());
  bean.setBeforePrintDataProcess(getPrintProcessor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.funcnode.ui.action.GroupAction getPrintMenuAction(){
 if(context.get("printMenuAction")!=null)
 return (nc.funcnode.ui.action.GroupAction)context.get("printMenuAction");
  nc.funcnode.ui.action.GroupAction bean = new nc.funcnode.ui.action.GroupAction();
  context.put("printMenuAction",bean);
  bean.setCode("printMenuAction");
  bean.setActions(getManagedList152());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList152(){  List list = new ArrayList();  list.add(getPrintAction());  list.add(getPreviewAction());  list.add(getOutputAction());  return list;}

public nc.ui.pubapp.uif2app.actions.LinkQueryAction getLinkQueryAction(){
 if(context.get("linkQueryAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.LinkQueryAction)context.get("linkQueryAction");
  nc.ui.pubapp.uif2app.actions.LinkQueryAction bean = new nc.ui.pubapp.uif2app.actions.LinkQueryAction();
  context.put("linkQueryAction",bean);
  bean.setModel(getManageAppModel());
  bean.setBillType("36FF");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.repay.action.ContractLinkQueryAction getContractlinkQueryAction(){
 if(context.get("ContractlinkQueryAction")!=null)
 return (nc.ui.pub.repay.action.ContractLinkQueryAction)context.get("ContractlinkQueryAction");
  nc.ui.pub.repay.action.ContractLinkQueryAction bean = new nc.ui.pub.repay.action.ContractLinkQueryAction();
  context.put("ContractlinkQueryAction",bean);
  bean.setModel(getManageAppModel());
  bean.setFuncode("36150BDC");
  bean.setCode("CONTRACT");
  bean.setBtnName(getI18nFB_66ca03());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private java.lang.String getI18nFB_66ca03(){
 if(context.get("nc.ui.uif2.I18nFB#66ca03")!=null)
 return (java.lang.String)context.get("nc.ui.uif2.I18nFB#66ca03");
  nc.ui.uif2.I18nFB bean = new nc.ui.uif2.I18nFB();
    context.put("&nc.ui.uif2.I18nFB#66ca03",bean);  bean.setResDir("3615cdm_0");
  bean.setDefaultValue("���д����ͬ");
  bean.setResId("03615cdm-0052");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
 try {
     Object product = bean.getObject();
    context.put("nc.ui.uif2.I18nFB#66ca03",product);
     return (java.lang.String)product;
}
catch(Exception e) { throw new RuntimeException(e);}}

public nc.ui.pubapp.uif2app.actions.pflow.PFApproveStatusInfoAction getQueryAuditFlowAction(){
 if(context.get("queryAuditFlowAction")!=null)
 return (nc.ui.pubapp.uif2app.actions.pflow.PFApproveStatusInfoAction)context.get("queryAuditFlowAction");
  nc.ui.pubapp.uif2app.actions.pflow.PFApproveStatusInfoAction bean = new nc.ui.pubapp.uif2app.actions.pflow.PFApproveStatusInfoAction();
  context.put("queryAuditFlowAction",bean);
  bean.setBillType("36FF");
  bean.setModel(getManageAppModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.lazilyload.DefaultBillLazilyLoader getBillLazilyLoader(){
 if(context.get("billLazilyLoader")!=null)
 return (nc.ui.pubapp.uif2app.lazilyload.DefaultBillLazilyLoader)context.get("billLazilyLoader");
  nc.ui.pubapp.uif2app.lazilyload.DefaultBillLazilyLoader bean = new nc.ui.pubapp.uif2app.lazilyload.DefaultBillLazilyLoader();
  context.put("billLazilyLoader",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.lazilyload.LazilyLoadManager getLasilyLodadMediator(){
 if(context.get("lasilyLodadMediator")!=null)
 return (nc.ui.pubapp.uif2app.lazilyload.LazilyLoadManager)context.get("lasilyLodadMediator");
  nc.ui.pubapp.uif2app.lazilyload.LazilyLoadManager bean = new nc.ui.pubapp.uif2app.lazilyload.LazilyLoadManager();
  context.put("lasilyLodadMediator",bean);
  bean.setModel(getManageAppModel());
  bean.setLoader(getBillLazilyLoader());
  bean.setLazilyLoadSupporter(getManagedList153());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList153(){  List list = new ArrayList();  list.add(getCardPanelLazilyLoad_58c9bc());  list.add(getListPanelLazilyLoad_124904a());  return list;}

private nc.ui.pubapp.uif2app.lazilyload.CardPanelLazilyLoad getCardPanelLazilyLoad_58c9bc(){
 if(context.get("nc.ui.pubapp.uif2app.lazilyload.CardPanelLazilyLoad#58c9bc")!=null)
 return (nc.ui.pubapp.uif2app.lazilyload.CardPanelLazilyLoad)context.get("nc.ui.pubapp.uif2app.lazilyload.CardPanelLazilyLoad#58c9bc");
  nc.ui.pubapp.uif2app.lazilyload.CardPanelLazilyLoad bean = new nc.ui.pubapp.uif2app.lazilyload.CardPanelLazilyLoad();
  context.put("nc.ui.pubapp.uif2app.lazilyload.CardPanelLazilyLoad#58c9bc",bean);
  bean.setBillform(getBillFormEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.pubapp.uif2app.lazilyload.ListPanelLazilyLoad getListPanelLazilyLoad_124904a(){
 if(context.get("nc.ui.pubapp.uif2app.lazilyload.ListPanelLazilyLoad#124904a")!=null)
 return (nc.ui.pubapp.uif2app.lazilyload.ListPanelLazilyLoad)context.get("nc.ui.pubapp.uif2app.lazilyload.ListPanelLazilyLoad#124904a");
  nc.ui.pubapp.uif2app.lazilyload.ListPanelLazilyLoad bean = new nc.ui.pubapp.uif2app.lazilyload.ListPanelLazilyLoad();
  context.put("nc.ui.pubapp.uif2app.lazilyload.ListPanelLazilyLoad#124904a",bean);
  bean.setListView(getListView());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.model.BillBodySortMediator getBillBodySortMediator(){
 if(context.get("billBodySortMediator")!=null)
 return (nc.ui.pubapp.uif2app.model.BillBodySortMediator)context.get("billBodySortMediator");
  nc.ui.pubapp.uif2app.model.BillBodySortMediator bean = new nc.ui.pubapp.uif2app.model.BillBodySortMediator(getManageAppModel(),getBillFormEditor(),getListView());  context.put("billBodySortMediator",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pub.repay.listener.RepayBillInitListener getInitDataListener(){
 if(context.get("initDataListener")!=null)
 return (nc.ui.pub.repay.listener.RepayBillInitListener)context.get("initDataListener");
  nc.ui.pub.repay.listener.RepayBillInitListener bean = new nc.ui.pub.repay.listener.RepayBillInitListener();
  context.put("initDataListener",bean);
  bean.setModel(getManageAppModel());
  bean.setContext(getContext());
  bean.setQueryAction(getQueryAction());
  bean.setPmodelDataManager(getModelDataManager());
  bean.setVoClassName("nc.vo.cdm.repayreceiptbankcredit.AggRePayReceiptBankCreditVO");
  bean.setAutoShowUpComponent(getBillFormEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.common.validateservice.ClosingCheck getClosingListener(){
 if(context.get("closingListener")!=null)
 return (nc.ui.pubapp.common.validateservice.ClosingCheck)context.get("closingListener");
  nc.ui.pubapp.common.validateservice.ClosingCheck bean = new nc.ui.pubapp.common.validateservice.ClosingCheck();
  context.put("closingListener",bean);
  bean.setModel(getManageAppModel());
  bean.setSaveAction(getSaveAction());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.view.FractionFixMediator getFractionFixMediator(){
 if(context.get("fractionFixMediator")!=null)
 return (nc.ui.pubapp.uif2app.view.FractionFixMediator)context.get("fractionFixMediator");
  nc.ui.pubapp.uif2app.view.FractionFixMediator bean = new nc.ui.pubapp.uif2app.view.FractionFixMediator(getBillFormEditor());  context.put("fractionFixMediator",bean);
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.uif2app.view.MouseClickShowPanelMediator getMouseClickShowPanelMediator(){
 if(context.get("mouseClickShowPanelMediator")!=null)
 return (nc.ui.pubapp.uif2app.view.MouseClickShowPanelMediator)context.get("mouseClickShowPanelMediator");
  nc.ui.pubapp.uif2app.view.MouseClickShowPanelMediator bean = new nc.ui.pubapp.uif2app.view.MouseClickShowPanelMediator();
  context.put("mouseClickShowPanelMediator",bean);
  bean.setListView(getListView());
  bean.setShowUpComponent(getBillFormEditor());
  bean.setHyperLinkColumn("vbillno");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.pubapp.bill.BillCodeMediator getBillCodeMediator(){
 if(context.get("billCodeMediator")!=null)
 return (nc.ui.pubapp.bill.BillCodeMediator)context.get("billCodeMediator");
  nc.ui.pubapp.bill.BillCodeMediator bean = new nc.ui.pubapp.bill.BillCodeMediator();
  context.put("billCodeMediator",bean);
  bean.setBillForm(getBillFormEditor());
  bean.setBillCodeKey("vbillno");
  bean.setBillType("36FF");
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.editor.UIF2RemoteCallCombinatorCaller getRemoteCallCombinatorCaller(){
 if(context.get("remoteCallCombinatorCaller")!=null)
 return (nc.ui.uif2.editor.UIF2RemoteCallCombinatorCaller)context.get("remoteCallCombinatorCaller");
  nc.ui.uif2.editor.UIF2RemoteCallCombinatorCaller bean = new nc.ui.uif2.editor.UIF2RemoteCallCombinatorCaller();
  context.put("remoteCallCombinatorCaller",bean);
  bean.setRemoteCallers(getManagedList154());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList154(){  List list = new ArrayList();  list.add(getQueryTemplateContainer());  list.add(getTemplateContainer());  list.add(getUserdefitemContainer());  return list;}

}
