package nc.ui.cdm.repayreceiptbankcredit.ace.handler;

import nc.ui.bd.ref.AbstractRefModel;
import nc.ui.pub.beans.UIRefPane;
import nc.ui.pub.bill.BillItem;
import nc.ui.pub.repay.listener.PayReceiptEditListener;
import nc.ui.pub.repay.listener.RePayPlanEditListener;
import nc.ui.pubapp.uif2app.event.IAppEventHandler;
import nc.ui.pubapp.uif2app.event.card.CardBodyBeforeEditEvent;
import nc.vo.cdm.repayreceiptbankcredit.RePayRcptBankInfo;
import nc.vo.gpm.guarantee.guacontract.EnumDebtType;
import nc.vo.pub.contract.ContractVO;
import nc.vo.pub.contract.GuaranteeTypeEnum;
import nc.vo.pub.repay.RepayReceiptBVO;

import org.apache.commons.lang3.StringUtils;

/**
 * �����ֶα༭ǰ�¼�������
 * 
 * @since 6.0
 * @version 2011-7-7 ����02:52:57
 * @author duy
 */
public class AceBodyBeforeEditHandler implements
		IAppEventHandler<CardBodyBeforeEditEvent> {

	@Override
	public void handleAppEvent(CardBodyBeforeEditEvent e) {
		e.setReturnValue(Boolean.TRUE);
		String key = e.getKey();
		String guaranteetype =(String)e.getBillCardPanel().getBodyValueAt(e.getRow(), "guantype");
//		String guaranteetype =(String)e.getBillCardPanel().getBodyItem("id_groupprotocoinfolvo","guantype").getValueObject();
		if (key.equals(RepayReceiptBVO.PK_REPAYPLAN)) {
			RePayPlanEditListener rePayPlanEH = new RePayPlanEditListener();
			rePayPlanEH.beforeEditEvent(e);
		} else if (key.equals(RepayReceiptBVO.PK_PAYRCPT)) {
			BillItem item = e.getBillCardPanel().getBodyItem(
					RepayReceiptBVO.PK_PAYRCPT);
			PayReceiptEditListener payReceptBEH = new PayReceiptEditListener(
					item);
			payReceptBEH.beforeEditEvent(e);
		}else if (ContractVO.PK_GUARANTEE.equals(key)) {//���嵣����ͬ
            //������ͬ
			String pk_contract = (String)e.getBillCardPanel().getHeadItem("pk_contract").getValueObject();
			if(StringUtils.isNotEmpty(guaranteetype) 
					&& (guaranteetype.equals(GuaranteeTypeEnum.BZ.toStringValue()) 
					|| guaranteetype.equals(GuaranteeTypeEnum.ZY.toStringValue())
					|| guaranteetype.equals(GuaranteeTypeEnum.DY.toStringValue())
					|| guaranteetype.equals(GuaranteeTypeEnum.HH.toStringValue()))
					&& StringUtils.isNotEmpty(pk_contract)){
				e.setReturnValue(true);
				UIRefPane ref = (UIRefPane) e.getBillCardPanel()
						.getBodyItem("id_groupprotocoinfolvo", ContractVO.PK_GUARANTEE)
						.getComponent();
				if (ref == null) {
					return;
				}
				AbstractRefModel model = ref.getRefModel();
				if (model == null) {
					return;
				}
				StringBuffer sql = new StringBuffer();
				sql.append("and pk_guacontract in (select pk_guarantee from cdm_gpminfo where pk_contract='"+pk_contract+"')");
				if (!guaranteetype
						.equalsIgnoreCase((String) GuaranteeTypeEnum.HH
								.value())) {
					sql.append("and  guatype='" + guaranteetype+ "'");
				}
				model.addWherePart(sql.toString());
//				QuoteGuaContractFilterListener quoteListener = new QuoteGuaContractFilterListener();
//				quoteListener.beforeEdit(e);
//				e.getBillCardPanel().getHeadItem(ContractVO.PK_GUARANTEE).setEnabled(true);
//				e.getBillCardPanel().getHeadItem(ContractVO.GUARANTEEAMOUNT).setEnabled(true);
			}else{
				e.setReturnValue(false);
				return;
			}
        	
		}
//		else if("pk_gpmcurr".equals(key)){//����
//			if(!StringUtil.isEmptyWithTrim(guaranteetype) && (guaranteetype.equals(GuaranteeTypeEnum.BZ.toStringValue()) 
//					|| guaranteetype.equals(GuaranteeTypeEnum.ZY.toStringValue())
//					|| guaranteetype.equals(GuaranteeTypeEnum.DY.toStringValue())
//					|| guaranteetype.equals(GuaranteeTypeEnum.HH.toStringValue()))){
//				e.setReturnValue(true);
//			}else{
//				e.setReturnValue(false);
//				return;
//			}
//        	
//		
//		}else if("guaranteeamount".equals(key)){//ռ�õ������
//			if(!StringUtil.isEmptyWithTrim(guaranteetype) && (guaranteetype.equals(GuaranteeTypeEnum.BZ.toStringValue()) 
//					|| guaranteetype.equals(GuaranteeTypeEnum.ZY.toStringValue())
//					|| guaranteetype.equals(GuaranteeTypeEnum.DY.toStringValue())
//					|| guaranteetype.equals(GuaranteeTypeEnum.HH.toStringValue()))){
//				e.setReturnValue(true);
//			}else{
//				e.setReturnValue(false);
//				return;
//			}
//        	
//		
//		}else if("guarantallamout".equals(key)){//�����ܽ��
//			if(!StringUtil.isEmptyWithTrim(guaranteetype) && (guaranteetype.equals(GuaranteeTypeEnum.BZ.toStringValue()) 
//					|| guaranteetype.equals(GuaranteeTypeEnum.ZY.toStringValue())
//					|| guaranteetype.equals(GuaranteeTypeEnum.DY.toStringValue())
//					|| guaranteetype.equals(GuaranteeTypeEnum.HH.toStringValue()))){
//				e.setReturnValue(true);
//			}else{
//				e.setReturnValue(false);
//				return;
//			}
//        	
//		
//		}
//		else if("guanrantorg".equals(key)){//������λ
//			if(!StringUtil.isEmptyWithTrim(guaranteetype) && (guaranteetype.equals(GuaranteeTypeEnum.BZ.toStringValue()) 
//					|| guaranteetype.equals(GuaranteeTypeEnum.ZY.toStringValue())
//					|| guaranteetype.equals(GuaranteeTypeEnum.DY.toStringValue())
//					|| guaranteetype.equals(GuaranteeTypeEnum.HH.toStringValue()))){
//				e.setReturnValue(true);
//			}else{
//				e.setReturnValue(false);
//				return;
//			}
//        	
//		
//		}
		else if(RePayRcptBankInfo.DEF2.equals(key)){//�ͷŵ������
			int row = e.getRow();
			Object guaranteeamount = e.getBillCardPanel().getBodyValueAt(e.getRow(), "guaranteeamount");
			if(null==guaranteeamount){
				e.setReturnValue(false);
			}else{
				e.setReturnValue(true);
				return;
			}
        	
		
		}
	}

}
