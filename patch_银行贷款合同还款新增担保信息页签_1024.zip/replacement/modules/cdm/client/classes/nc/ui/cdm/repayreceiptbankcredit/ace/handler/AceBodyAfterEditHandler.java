package nc.ui.cdm.repayreceiptbankcredit.ace.handler;

import nc.bs.framework.common.NCLocator;
import nc.itf.uap.IUAPQueryBS;
import nc.jdbc.framework.processor.ColumnProcessor;
import nc.ui.pub.beans.UIRefPane;
import nc.ui.pub.bill.BillItem;
import nc.ui.pub.repay.listener.PayReceiptEditListener;
import nc.ui.pub.repay.listener.RePayAmountEditListener;
import nc.ui.pub.repay.listener.RePayPlanEditListener;
import nc.ui.pubapp.uif2app.event.IAppEventHandler;
import nc.ui.pubapp.uif2app.event.card.CardBodyAfterEditEvent;
import nc.ui.pubapp.uif2app.view.BillForm;
import nc.vo.cdm.repayreceiptbankcredit.RePayRcptBankInfo;
import nc.vo.jcom.lang.StringUtil;
import nc.vo.pm.util.UFDoubleUtils;
import nc.vo.pub.BusinessException;
import nc.vo.pub.contract.ContractVO;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.repay.RepayReceiptBVO;
import nc.vo.pubapp.pattern.exception.ExceptionUtils;

import org.apache.commons.lang.StringUtils;

/**
 * ���ݱ����ֶα༭���¼�
 * 
 * @since 6.0
 * @version 2011-7-12 ����08:17:33
 * @author duy
 */
public class AceBodyAfterEditHandler implements
		IAppEventHandler<CardBodyAfterEditEvent> {

	private BillForm billfrom;

    public AceBodyAfterEditHandler(BillForm bill) {
        this.billfrom = bill;
    }
	@Override
	public void handleAppEvent(CardBodyAfterEditEvent e) {
		String key = e.getKey();
		if (key.equals(RepayReceiptBVO.PK_REPAYPLAN)) {
			RePayPlanEditListener rePayPlanEH = new RePayPlanEditListener();
			rePayPlanEH.afterEditEvent(billfrom,e);
		}else if(key.equals(RepayReceiptBVO.PK_PAYRCPT)){
			BillItem item = e.getBillCardPanel().getBodyItem(RepayReceiptBVO.PK_PAYRCPT);
			PayReceiptEditListener payReceiptAEH = new PayReceiptEditListener(item);
			payReceiptAEH.afterEditEvent(billfrom,e);
		}else if(key.equals(RepayReceiptBVO.REPAYAMOUNT)){
			RePayAmountEditListener rePayAmountEL = new RePayAmountEditListener();
			rePayAmountEL.afterEditEvent(billfrom,e);
		}else if(ContractVO.PK_GUARANTEE.equals(key)){
        	String pk_guarantee = (String) e.getBillCardPanel().getBodyItem(ContractVO.PK_GUARANTEE).getValueObject();
        	if(StringUtil.isEmptyWithTrim(pk_guarantee)){
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), ContractVO.PK_GPMCURR);
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), ContractVO.GUARANTEEAMOUNT);
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), RePayRcptBankInfo.GUANSTARTDATE);
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), RePayRcptBankInfo.GUANENDDATE);
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), RePayRcptBankInfo.GUARANTALLAMOUT);
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), RePayRcptBankInfo.GUANRANTORG);
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), RePayRcptBankInfo.DEF1);
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), RePayRcptBankInfo.DEF2);
        	}else{
        		UIRefPane refPanel = (UIRefPane)e.getBillCardPanel().getBodyItem(ContractVO.PK_GUARANTEE).getComponent();
        		String pk_gpmcurr = (String) refPanel.getRefModel().getValue("pk_guacurrtype");//��������
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt((Object)pk_gpmcurr, e.getRow(), ContractVO.PK_GPMCURR);
        		String guaStartDate = (String)refPanel.getRefModel().getValue("guastartdate");//��ʼ����
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt((Object)guaStartDate, e.getRow(), RePayRcptBankInfo.GUANSTARTDATE);
        		String guaenddate = (String)refPanel.getRefModel().getValue("guaenddate");//��������
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt((Object)guaenddate, e.getRow(), RePayRcptBankInfo.GUANENDDATE);
        		String guaallamout = (String)refPanel.getRefModel().getValue("guaamount");//�����ܽ��
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt((Object)guaallamout, e.getRow(), RePayRcptBankInfo.GUARANTALLAMOUT);
        		String guanrantorg = (String)refPanel.getRefModel().getValue("guarantor");//������λ
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt((Object)guanrantorg, e.getRow(), RePayRcptBankInfo.GUANRANTORG);
        		String vdef1 = (String)refPanel.getRefModel().getValue("vdef1");//��ͬ�ܽ��def1
        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt((Object)vdef1, e.getRow(), RePayRcptBankInfo.DEF1);
        		//ͨ�����д����ͬ��ȡռ�ý�� cdm_gpminfo
        		String pk_contract = (String)e.getBillCardPanel().getHeadItem("pk_contract").getValueObject();
        		String sql ="select guaranteeamount from cdm_gpminfo where pk_contract='"+pk_contract+"' and pk_guarantee='"+pk_guarantee+"';";
        		IUAPQueryBS bs = NCLocator.getInstance().lookup(IUAPQueryBS.class);
        		Object guaranteeamount = null;
					try {
						guaranteeamount = bs.executeQuery(sql, new ColumnProcessor());
					} catch (BusinessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt((Object)guaranteeamount, e.getRow(), RePayRcptBankInfo.GUARANTEEAMOUNT);
//        		FireEventManager.fireBodyItemEditEvent(getModel(), e.getBillCardPanel(), ContractVO.PK_GPMCURR, e.getRow());
        	}
        }else if(key.equals(RePayRcptBankInfo.DEF2)){
        	UFDouble guaranteeamount =(UFDouble)e.getBillCardPanel().getBodyValueAt(e.getRow(), "guaranteeamount");
//        	String guaranteeamount =(String)e.getBillCardPanel().getBodyItem("id_groupprotocoinfolvo","guaranteeamount").getValueObject();
        	BillItem def2BodyItem = e.getBillCardPanel().getBodyItem("id_groupprotocoinfolvo","def2");
        	String def2 =(String)def2BodyItem.getValueObject();
        	if(StringUtils.isNotEmpty(def2)){
	        	if(null!=guaranteeamount){
	        		if(guaranteeamount.toDouble()<UFDoubleUtils.objToUFDouble(def2).toDouble()){
	        			e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), RePayRcptBankInfo.DEF2);
	        			ExceptionUtils.wrappBusinessException("�ͷŽ��ܴ���ռ�õ������!");
	        		}
	        	}else{
	        		e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo").setValueAt(null, e.getRow(), RePayRcptBankInfo.DEF2);
	        		ExceptionUtils.wrappBusinessException("ռ�õ�������Ϊ��!");
	        	}
        	}
		}
	}

}
