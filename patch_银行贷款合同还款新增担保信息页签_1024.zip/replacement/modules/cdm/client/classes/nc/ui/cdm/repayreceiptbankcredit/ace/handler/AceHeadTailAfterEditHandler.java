package nc.ui.cdm.repayreceiptbankcredit.ace.handler;

import nc.ui.pub.bill.BillItem;
import nc.ui.pub.bill.BillModel;
import nc.ui.pub.repay.listener.CalculatorEditListener;
import nc.ui.pub.repay.listener.ContractEditListener;
import nc.ui.pub.repay.listener.DebitprofEditListener;
import nc.ui.pub.repay.listener.ForeignRateEditListener;
import nc.ui.pub.repay.listener.ForeigncurrEditListener;
import nc.ui.pub.repay.listener.InterestEditListener;
import nc.ui.pub.repay.listener.IsForeignEditListener;
import nc.ui.pub.repay.listener.RePayDateEditListener;
import nc.ui.pubapp.uif2app.event.IAppEventHandler;
import nc.ui.pubapp.uif2app.event.card.CardHeadTailAfterEditEvent;
import nc.ui.pubapp.uif2app.view.BillForm;
import nc.ui.tmpub.repay.listener.IsPayReleaseEditListener;
import nc.ui.tmpub.repay.listener.PayReleaseAmountEditListener;
import nc.vo.pub.repay.RepayReceiptVO;

/**
 * ���ݱ�ͷ��β�ֶα༭���¼�������
 * 
 * @since 6.0
 * @version 2011-7-7 ����02:52:22
 * @author duy
 */
public class AceHeadTailAfterEditHandler implements
		IAppEventHandler<CardHeadTailAfterEditEvent> {

	private BillForm billfrom;
	private CalculatorEditListener digitListener;

    public AceHeadTailAfterEditHandler(BillForm bill) {
        this.billfrom = bill;
    }
    public CalculatorEditListener getDigitListener() {
		return digitListener;
	}
	public void setDigitListener(CalculatorEditListener digitListener) {
		this.digitListener = digitListener;
	}
	@Override
	public void handleAppEvent(CardHeadTailAfterEditEvent e) {
		String key = e.getKey();
		if (key.equals(RepayReceiptVO.PK_CONTRACT)) {
			//������ͬ����������嵣����Ϣ
			BillModel billModel = e.getBillCardPanel().getBillModel("id_groupprotocoinfolvo");
			int rowCount = billModel.getRowCount();
			for(int row=rowCount-1 ;row>=0;row--){
				billModel.removeRow(row);
			}
			ContractEditListener contractEL = new ContractEditListener();
			contractEL.setDigitListener(getDigitListener());
			contractEL.afterEditEvent(billfrom,e);
		}else if(key.equals(RepayReceiptVO.INTEREST)){
			InterestEditListener interestEL = new InterestEditListener();
			interestEL.afterEditEvent(billfrom,e);
		}else if(key.equals(RepayReceiptVO.ISFOREIGN)){
			IsForeignEditListener isForeignEL = new IsForeignEditListener();
			isForeignEL.afterEditEvent(e);
		}else if(key.equals(RepayReceiptVO.REPAYDATE)||RepayReceiptVO.ISINITIAL.equals(key)){
			RePayDateEditListener repayDateEL = new RePayDateEditListener();
			repayDateEL.afterEditEvent(billfrom,e);
		}else if(key.equals(RepayReceiptVO.FOREIGNRATE)){
			ForeignRateEditListener foreignRateEL = new ForeignRateEditListener();
			foreignRateEL.afterEditEvent(e);
		}else if(key.equals(RepayReceiptVO.PK_FOREIGNCURR)){
			ForeigncurrEditListener foreigncurrEL = new ForeigncurrEditListener();
			foreigncurrEL.afterEditEvent(billfrom,e);
		}else if(RepayReceiptVO.PK_DEBITPROF.equals(key)){
			DebitprofEditListener debitprofEL = new DebitprofEditListener();
			debitprofEL.afterEditEvent(e);
		}else if(RepayReceiptVO.ISPAYRELEASE.equals(key)){
			new IsPayReleaseEditListener().afterEdit(e);
		}else if(RepayReceiptVO.PAYRELEASEAMOUNT.equals(key)){
			new PayReleaseAmountEditListener().afterEdit(e);
		}else if("pk_contract.isfixrate".equals(key))
        {
        	digitListener.IsCalculatorEdit(e);
        }
		
	}

}
